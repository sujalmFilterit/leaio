
import domToImage from "dom-to-image";
import { downloadURI, onExpand as libOnExpand } from "@/lib/utils";
import { Dispatch, SetStateAction } from "react";

export interface CardRefs {
  current: Record<string, HTMLElement | null>;
}

export interface ExpandParams {
  key: string;
  cardRefs: CardRefs;
  expandedCard: string | null;
  setExpandedCard: Dispatch<SetStateAction<string | null>>;
}

export interface ExportPngParams {
  element: HTMLElement | null;
  filename: string;
  onError?: (error: Error) => void;
  onSuccess?: () => void;
}

export interface ExportPngByKeyParams {
  cardRefs: CardRefs;
  key: string;
  filename: string;
  onError?: (error: Error) => void;
  onSuccess?: () => void;
}

export interface ExportCsvFromUrlParams {
  url: string;
  filename: string;
  onError?: (error: Error) => void;
  onSuccess?: () => void;
}

export interface ExportCsvFromApiParams {
  apiCall: () => Promise<{ url?: string } | { data?: { url?: string } }>;
  filename: string;
  onError?: (error: Error) => void;
  onSuccess?: () => void;
  onLoading?: (loading: boolean) => void;
}

export interface ExportCsvWithPayloadParams {
  payload: any;
  apiHook: {
    refetch: () => Promise<{ url?: string } | { data?: { url?: string } }>;
  };
  filename: string;
  onError?: (error: Error) => void;
  onSuccess?: () => void;
  onLoading?: (loading: boolean) => void;
}


export const handleExpand = (params: ExpandParams): void => {
  const { key, cardRefs, expandedCard, setExpandedCard } = params;
  libOnExpand(key, cardRefs, expandedCard, setExpandedCard);
};

export const exportPng = async (params: ExportPngParams): Promise<void> => {
  const { element, filename, onError, onSuccess } = params;

  if (!element) {
    const error = new Error(`Export failed: Element is null`);
    onError?.(error);
    console.error(error.message);
    return;
  }

  try {
    const screenshot = await domToImage.toPng(element);
    downloadURI(screenshot, `${filename}.png`);
    onSuccess?.();
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    onError?.(err);
    console.error("Error exporting PNG:", err);
  }
};


export const exportPngByKey = async (params: ExportPngByKeyParams): Promise<void> => {
  const { cardRefs, key, filename, onError, onSuccess } = params;

  const element = cardRefs.current?.[key];

  if (!element) {
    const error = new Error(`Export failed: No element found for key "${key}"`);
    onError?.(error);
    console.error(error.message);
    return;
  }

  await exportPng({ element, filename, onError, onSuccess });
};

export const exportCsvFromUrl = (params: ExportCsvFromUrlParams): void => {
  const { url, filename, onError, onSuccess } = params;

  try {
    if (!url) {
      throw new Error("URL is required for CSV export");
    }

    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", filename.endsWith(".csv") ? filename : `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onSuccess?.();
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    onError?.(err);
    console.error("Error downloading CSV:", err);
  }
};


export const exportCsvFromApi = async (params: ExportCsvFromApiParams): Promise<void> => {
  const { apiCall, filename, onError, onSuccess, onLoading } = params;

  try {
    onLoading?.(true);
    const response = await apiCall();
    
    // Handle different response structures
    const url = (response as any)?.url || (response as any)?.data?.url;
    
    if (!url) {
      throw new Error("API response does not contain a URL");
    }

    exportCsvFromUrl({ url, filename, onError, onSuccess });
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    onError?.(err);
    console.error("Error exporting CSV from API:", err);
  } finally {
    onLoading?.(false);
  }
};


export const exportCsvWithPayload = async (params: ExportCsvWithPayloadParams): Promise<void> => {
  const { payload, apiHook, filename, onError, onSuccess, onLoading } = params;

  try {
    onLoading?.(true);
    
    // Add export_type to payload
    const exportPayload = {
      ...payload,
      export_type: "csv",
    };

    // Call API with modified payload
    const response = await apiHook.refetch();
    
    // Handle different response structures
    const url = (response as any)?.url || (response as any)?.data?.url;
    
    if (!url) {
      throw new Error("API response does not contain a URL");
    }

    exportCsvFromUrl({ url, filename, onError, onSuccess });
  } catch (error) {
    const err = error instanceof Error ? error : new Error(String(error));
    onError?.(err);
    console.error("Error exporting CSV with payload:", err);
  } finally {
    onLoading?.(false);
  }
};


export const createCsvExportHandler = (params: ExportCsvFromApiParams) => {
  return () => exportCsvFromApi(params);
};

export const createCsvExportWithPayloadHandler = (params: ExportCsvWithPayloadParams) => {
  return () => exportCsvWithPayload(params);
};


export const createPngExportHandler = (params: ExportPngByKeyParams) => {
  return () => exportPngByKey(params);
};

export const createExpandHandler = (params: ExpandParams) => {
  return () => handleExpand(params);
};

