"use client";
import React, { useRef, Dispatch, SetStateAction } from "react";
import { Card } from "@/components/ui/card";
import { onExpand, downloadURI } from "@/lib/utils";
import DonutChart from "@/components/mf/charts/DonutChart";
import ChartAreaGradient from "@/components/mf/charts/ChartAreaGradient";
import ProgressBarChart from "@/components/mf/charts/ProgressBarChart";
import StackedBarChart from "@/components/mf/charts/stackedBarChart";
import domToImage from "dom-to-image";
import {
  PieChart,
  BarChart3,
  TrendingUp,
  Users,
  Building2,
  Sparkles,
} from "lucide-react";

interface InDepthAnomalyAnalysisProps {
  // Fraud Categories Donut Chart
  donutData: any[];
  donutConfig: any;
  fraudStatsLoading: boolean;
  isExportingFraudCategories: boolean;
  onDonutSegmentClick: (data: any) => void;
  refetchFraudCategories: () => void;

  // Progress Bar Chart
  progressBarData: any[];
  progressBarLoading: boolean;
  isExportingProgressBar: boolean;
  refetchProgressBar: () => void;

  // Area Chart
  areaChartData1: any[];
  areaBarConfig: any;
  areaChartApiLoading: boolean;
  isExportingAreaChart: boolean;
  refetchAreaChart: () => void;

  // Reattribution Chart
  reattributionChartData: any[];
  reattributionStackedBarConfig: any;
  reattributionLoading: boolean;
  isExportingReattribution: boolean;
  refetchReattribution: () => void;

  // Common props
  onclickvalue: string;
  selectedRadio1: "Publisher" | "Vendor";
  setSelectedRadio1: (value: "Publisher" | "Vendor") => void;
  isInitialLoading: boolean;
  cardRefs: React.MutableRefObject<Record<string, HTMLElement | null>>;
  expandedCard: string | null;
  setExpandedCard: Dispatch<SetStateAction<string | null>>;
}

const InDepthAnomalyAnalysis: React.FC<InDepthAnomalyAnalysisProps> = ({
  donutData,
  donutConfig,
  fraudStatsLoading,
  isExportingFraudCategories,
  onDonutSegmentClick,
  refetchFraudCategories,
  progressBarData,
  progressBarLoading,
  isExportingProgressBar,
  refetchProgressBar,
  areaChartData1,
  areaBarConfig,
  areaChartApiLoading,
  isExportingAreaChart,
  refetchAreaChart,
  reattributionChartData,
  reattributionStackedBarConfig,
  reattributionLoading,
  isExportingReattribution,
  refetchReattribution,
  onclickvalue,
  selectedRadio1,
  setSelectedRadio1,
  isInitialLoading,
  cardRefs,
  expandedCard,
  setExpandedCard,
}) => {
  const handleExpand = (key: string) => {
    onExpand(key, cardRefs, expandedCard, setExpandedCard);
  };

  const handleExportPng = async (title: string, key: string) => {
    try {
      const ref = cardRefs.current?.[key];
      if (!ref) {
        console.error(`Export failed: No element found for key "${key}"`);
        return;
      }

      const screenshot = await domToImage.toPng(ref);
      downloadURI(screenshot, title + ".png");
    } catch (error) {
      console.error("Error exporting PNG:", error);
    }
  };

  const onExport = async (format: string, title: string, key: string) => {
    try {
      if (format !== "png") {
        console.warn(
          `Export format "${format}" not supported. Only PNG is supported.`
        );
        return;
      }

      const ref = cardRefs.current?.[key];
      if (!ref) {
        console.error(`Export failed: No element found for key "${key}"`);
        return;
      }

      const screenshot = await domToImage.toPng(ref);
      downloadURI(screenshot, title + ".png");
    } catch (error) {
      console.error("Error exporting PNG:", error);
    }
  };

  return (
    <>
      {/* Modern Card Container with Glassmorphism */}
      <div className=" flex flex-col  w-full backdrop-blur-lg bg-background/80 dark:bg-card/80 border border-border/40 rounded-xl shadow-lg p-2 transition-all duration-300">
        <div className="w-full space-y-2">
          {/* Modern Section Header */}
          <div className="w-full">
            <div className="flex items-center justify-center gap-2">
              <div className="h-8 w-1 bg-gradient-to-b from-primary to-secondary rounded-full" />

              <h2 className="text-lg sm:text-xl font-bold text-foreground gradient-text">
                In-Depth Anomaly Analysis
              </h2>
              <div className="h-8 w-1 bg-gradient-to-b from-secondary to-primary rounded-full" />
            </div>
          </div>

          {/* Charts Grid */}
          <div className="w-full">
            <div
              className="grid grid-cols-1 lg:grid-cols-3 w-full gap-2 transition-all duration-300"
              ref={(el) => {
                if (el) cardRefs.current!["fraud_categories"] = el;
              }}
            >
              {/* Fraud Categories Donut Chart */}
              <div className="transition-all duration-300 hover:shadow-xl">
                <DonutChart
                  chartData={donutData}
                  chartConfig={donutConfig}
                  onExport={() => {
                    onExport("png", "Fraud Categories", "fraud_categories");
                  }}
                  onExpand={() => {
                    handleExpand("fraud_categories");
                  }}
                  title="Fraud Categories"
                  titleIcon={<PieChart className="w-4 h-4 text-primary" />}
                  isLoading={fraudStatsLoading || isInitialLoading}
                  dataKey="visit"
                  nameKey="label"
                  isView={true}
                  direction="flex-col"
                  isdonut={false}
                  marginTop="mt-0"
                  position="items-start"
                  isPercentage={false}
                  isPercentageValue={true}
                  istotalvistors={false}
                  handleExport={() => {
                    refetchFraudCategories();
                  }}
                  onSegmentClick={onDonutSegmentClick}
                  cardHeight="19.6875rem"
                  contentHeight="14.375rem"
                  displayMode="both"
                />
              </div>

              {/* Progress Bar Chart */}
              <div
                ref={(el) => {
                  if (el) cardRefs.current!["fraud_sub_categories"] = el;
                }}
                className="col-span-2 transition-all duration-300  hover:shadow-xl"
              >
                <ProgressBarChart
                  cardHeight="19.6875rem"
                  contentHeight="14.375rem"
                  chartData={progressBarData}
                  title={`Fraud Sub Categories for ${onclickvalue ? `${onclickvalue}` : "Click Fraud"}`}
                  titleIcon={<BarChart3 className="w-4 h-4 text-primary" />}
                  isLoading={progressBarLoading || isInitialLoading}
                  handleExportCsv={() => {
                    refetchProgressBar();
                  }}
                  handleExpand={() => handleExpand("fraud_sub_categories")}
                  handleExportPng={() => {
                    handleExportPng(
                      "Fraud Sub Categories",
                      "fraud_sub_categories"
                    );
                  }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Second Row - Date Wise & Publisher/Vendor Analysis */}
        <div className="w-full mt-2">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
            {/* Area Chart */}
            <div className="transition-all duration-300 h-auto hover:shadow-xl">
              <ChartAreaGradient
                chartData={areaChartData1}
                chartConfig={areaBarConfig}
                XaxisLine={true}
                Xdatakey="label"
                CartesianGridVertical={true}
                title={`Date Wise Fraud Sub Categories For ${onclickvalue ? `${onclickvalue}` : "Click Fraud"}`}
                titleIcon={<TrendingUp className="w-4 h-4 text-primary" />}
                handleExportCsv={() => {
                  refetchAreaChart();
                }}
                handleExpand={() =>
                  handleExpand("date_wise_fraud_sub_categories")
                }
                handleExportPng={() => {
                  handleExportPng(
                    "Date Wise Fraud Sub Categories",
                    "date_wise_fraud_sub_categories"
                  );
                }}
                exportKey="date_wise_fraud_sub_categories"
                isLoading={areaChartApiLoading || isInitialLoading}
                cardHeight="18rem"
                height="12rem"
                contentHeight="11rem"
                chartMargins={{ top: 0, right: -10, left: -10, bottom: 0 }}
              />
            </div>

            {/* Stacked Bar Chart */}
            <div className="">
              <StackedBarChart
                ref={(el) => {
                  if (el)
                    cardRefs.current!["publisher_vendor_fraud_sub_categories"] =
                      el;
                }}
                chartData={reattributionChartData}
                chartConfig={reattributionStackedBarConfig}
                title={
                  selectedRadio1 === "Publisher"
                    ? `Publisher Wise Fraud Sub Categories For ${onclickvalue ? `${onclickvalue}` : "Click Fraud"}`
                    : `Agency Wise Fraud Sub Categories For ${onclickvalue ? `${onclickvalue}` : "Click Fraud"} Trend`
                }
                titleIcon={
                  selectedRadio1 === "Publisher" ? (
                    <Users className="w-4 h-4 text-primary" />
                  ) : (
                    <Building2 className="w-4 h-4 text-primary" />
                  )
                }
                onExport={() => {
                  onExport(
                    "png",
                    "Publisher/Vendor Wise Fraud Sub Categories",
                    "publisher_vendor_fraud_sub_categories"
                  );
                }}
                exportKey="publisher_vendor_fraud_sub_categories"
                onExpand={() => {
                  handleExpand("publisher_vendor_fraud_sub_categories");
                }}
                isLoading={reattributionLoading || isInitialLoading}
                isHorizontal={true}
                isInformCard={false}
                isLegend={true}
                isCartesian={true}
                yAxis={{ dataKey: "label" }}
                AxisLabel="Count"
                handleExport={() => {
                  refetchReattribution();
                }}
                filterType="radio"
                filterOptions={[
                  { value: "Publisher", label: "Publisher" },
                  { value: "Vendor", label: "Agency" },
                ]}
                selectedFilterValue={selectedRadio1}
                handleFilterChange={(value: string | string[]) =>
                  setSelectedRadio1(value as "Publisher" | "Vendor")
                }
                showMenu={true}
                
                barHeight="13rem"
                cardHeight="18rem"
                chartMargins={{ top: 0, right: -10, left: -10, bottom: 0 }}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default InDepthAnomalyAnalysis;
