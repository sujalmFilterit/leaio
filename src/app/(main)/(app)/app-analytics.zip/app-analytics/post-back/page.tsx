"use client";
import React, {
  useEffect,
  useState,
  useMemo,
} from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Filter } from "@/components/mf/Filters/Filter";
import ResizableTable from "@/components/mf/ReportingToolTable";
import { usePackage } from "@/components/mf/PackageContext";
import { useDateRange } from "@/components/mf/DateRangeContext";
import { usePostBackTable } from "../hooks/usePostBack";
import { useAppAnalyticsFilters } from "../hooks/useAppAnalyticsFilters";
import { createPostbackFilters } from "../hooks/filterConfigHelpers";

interface PostbackEventData {
  Date: string;
  "Publisher Name": string;
  "Event Type": string;
  "Total Counts": number;
  "Invalid Events": number;
  "Valid Events": number;
  "Postback Triggered Events": number;
  [key: string]: string | number; 
}

const PostTracking = () => {
  const { selectedPackage } = usePackage();
  const { startDate, endDate } = useDateRange();
  const [currentPage, setCurrentPage] = useState(1);
  const [recordLimit, setRecordLimit] = useState(10);
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [resetTimestamp, setResetTimestamp] = useState(Date.now());

  const [tableData, setTableData] = useState<PostbackEventData[]>([]);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);

  // Base filter payload
  const baseFilterPayload = useMemo(() => {
    if (selectedPackage && startDate && endDate) {
      return {
        package_name: selectedPackage,
        start_date: startDate,
        end_date: endDate,
      };
    }
    return undefined;
  }, [selectedPackage, startDate, endDate]);

  // Use centralized filter hook
  const filterConfigs = useMemo(() => createPostbackFilters(), []);
  const {
    query,
    filterConfig,
    filterData,
    handlePublisherFilterChange,
    handleOtherFiltersChange,
    resetFilters,
  } = useAppAnalyticsFilters(filterConfigs, baseFilterPayload);

  // Postback events summary API payload
  const postbackPayload = useMemo(() => {
    if (
      selectedPackage &&
      startDate &&
      endDate &&
      filterData.publishers &&
      filterData.event_type &&
      (filterData.publishers as any).Affiliate?.length > 0 &&
      (filterData.event_type as string[]).length > 0
    ) {
      const publisherPayload = query.publishers?.includes("all")
        ? ["all"]
        : query.publishers || ["all"];

      const eventTypePayload = query.event_type?.includes("all")
        ? ["all"]
        : query.event_type || ["all"];

      if (publisherPayload.length > 0 && eventTypePayload.length > 0) {
        return {
          package_name: selectedPackage,
          start_date: startDate,
          end_date: endDate,
          publisher: publisherPayload,
          event_type: eventTypePayload,
          record_limit: recordLimit,
          page_number: currentPage,
          search: debouncedSearchTerm,
        };
      }
    }
    return undefined;
  }, [
    selectedPackage,
    startDate,
    endDate,
    query.publishers,
    query.event_type,
    filterData.publishers,
    filterData.event_type,
    recordLimit,
    currentPage,
    debouncedSearchTerm,
  ]);

  // Postback events summary API
  const {
    data: postbackEventsData,
    isLoading: postbackEventsLoading,
  } = usePostBackTable(postbackPayload, !!postbackPayload);

  const isPostbackLoading = postbackEventsLoading;

  // Update table data from API response
  useEffect(() => {
    if (postbackEventsData) {
      const response = Array.isArray(postbackEventsData)
        ? { data: postbackEventsData }
        : postbackEventsData;

      if (response.data) {
        setTableData(response.data);
      }
      if (response.Total_pages !== undefined) {
        setTotalPages(response.Total_pages);
      }
      if (response.Total_records !== undefined) {
        setTotalRecords(response.Total_records);
      }
    }
  }, [postbackEventsData]);

  // Reset when package/date changes
  useEffect(() => {
    setResetTimestamp(Date.now());
    resetFilters();
    setSearchTerm("");
    setDebouncedSearchTerm("");
    setTableData([]);
    setTotalPages(1);
    setTotalRecords(0);
    setCurrentPage(1);
  }, [selectedPackage, startDate, endDate, resetFilters]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
    setSearchTerm(""); // Reset search when filters change
    setDebouncedSearchTerm(""); // Reset debounced search when filters change
  }, [query.publishers, query.event_type]);

  // Debounced search effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 1500); // 500ms delay

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Get publisher data for publisherGroups prop
  const publisherGroups = useMemo(() => {
    const publishers = filterData.publishers as any;
    return publishers && typeof publishers === 'object' && !Array.isArray(publishers)
      ? { Publishers: publishers }
      : { Publishers: { Affiliate: [], "Whitelisted Publisher": [] } };
  }, [filterData.publishers]);

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  // Handle limit change
  const handleLimitChange = (limit: number) => {
    setRecordLimit(limit);
    setCurrentPage(1); // Reset to first page when limit changes
  };

  // Create table columns dynamically based on data
  const tableColumns = useMemo(() => {
    if (tableData.length === 0) return [];

    const firstRow = tableData[0];
    return Object.keys(firstRow).map((key) => ({
      title: key,
      key: key,
    }));
  }, [tableData]);

  return (
    <div className="space-y-2">
      <div className="sticky top-0 z-50 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 rounded-md bg-background px-4 py-3 border border-gray-200">
    
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full">
          <Filter
            key={`publishers-${resetTimestamp}-${selectedPackage}`}
            filter={filterConfig.publishersFilter}
            onChange={handlePublisherFilterChange}
            grouped={true}
            publisherGroups={publisherGroups}
          />
          <Filter
            key={`other-${resetTimestamp}`}
            filter={filterConfig.otherFilters}
            onChange={handleOtherFiltersChange}
            grouped={false}
          />
        </div>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="pt-6">
              <ResizableTable
                columns={tableColumns}
                data={tableData}
                headerColor="#f3f4f6"
                isPaginated={true}
                isSearchable={true}
                onSearch={(searchTerm) => {
                  setSearchTerm(searchTerm);
                }}
                isLoading={isPostbackLoading}
                onPageChange={handlePageChange}
                onLimitChange={handleLimitChange}
                pageNo={currentPage}
                totalPages={totalPages}
                limit={recordLimit}
                totalRecords={totalRecords}
                emptyStateMessage="No Data Found!"
                isTableDownload={false}
                isRefetch={false}
              />
        </CardContent>
      </Card>
    </div>
  );
};

export default PostTracking;
