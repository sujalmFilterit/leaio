// "use client";
// import React, { useState } from "react";
// import { useTheme } from "@/components/mf/theme-context";
// import MFWebFraudAsideMenu from "@/components/mf/MFWebFraudAsideMenu";
// import { MFTopBar } from "@/components/mf";
// import { QueryClientProvider } from '@tanstack/react-query';
// import { queryClient } from '@/lib/queryClient';
// import { usePathname } from 'next/navigation';
// import { SessionCheck } from "@/components/mf/SessionCheck";
// import { ScrollToTop } from "@/components/mf/ScrollToTop";

// export default function AppFraudLayout({
//   children,
// }: {
//   children: React.ReactNode;
// }) {
//   const { isDarkMode } = useTheme();
//   const [IsHover, setIsHover] = useState(false);
//   const [Toggle, setToggle] = useState(false);
//   const pathname = usePathname();

//   const currentTheme = isDarkMode ? "dark" : "light";

//   return (
//     <div className="flex h-screen flex-col w-full dark:bg-black">
//       {/* Header */}
//       <MFTopBar
//         isExpanded={Toggle || IsHover}
//         onToggle={() => setToggle(!Toggle)}
//         isCalender={true}
//       />

//       {/* Main content area */}
//       <div className="flex flex-1 overflow-hidden">
//         <MFWebFraudAsideMenu
//           isExpanded={Toggle || IsHover}
//           onHover={setIsHover}
//           theme={currentTheme}
//         />
//         <SessionCheck>
//           <QueryClientProvider client={queryClient}>
//             <div 
//               id="app-analytics-scroll-container"
//               className="flex-1 overflow-auto bg-gray-100 px-2 dark:bg-background"
//             >
//               {children}
//               <ScrollToTop
//                 threshold={100}
//                 position="bottom-right"
//                 scrollContainer="#app-analytics-scroll-container"
//               />
//             </div>
//           </QueryClientProvider>
//         </SessionCheck>
//       </div>
//     </div>
//   );
// } 



"use client";
import React, { useState } from "react";
import { useTheme } from "@/components/mf/theme-context";
import MFWebFraudAsideMenu from "@/components/mf/MFWebFraudAsideMenu";
import { MFTopBar } from "@/components/mf";
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { usePathname } from 'next/navigation';
import { SessionCheck } from "@/components/mf/SessionCheck";
import { ScrollProgress } from "@/components/mf/ScrollProgress";
import { ScrollToTop } from "@/components/mf/ScrollToTop";
 
export default function AppFraudLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isDarkMode } = useTheme();
  const [IsHover, setIsHover] = useState(false);
  const [Toggle, setToggle] = useState(false);
  const pathname = usePathname();
 
  const currentTheme = isDarkMode ? "dark" : "light";
 
  return (
    <div className="flex h-screen flex-col w-full dark:bg-black">
      {/* Scroll Progress Bar - Fixed above top bar, at the very top */}
      <ScrollProgress
        scrollContainer="#app-analytics-scroll-container"
        height={3}
        color="bg-primary dark:bg-primary"
        position="top"
      />
 
      {/* Header */}
      <MFTopBar
        isExpanded={Toggle || IsHover}
        onToggle={() => setToggle(!Toggle)}
        isCalender={true}
      />
 
      {/* Main content area */}
      <div className="flex flex-1 overflow-hidden relative">
        <MFWebFraudAsideMenu
          isExpanded={Toggle || IsHover}
          onHover={setIsHover}
          theme={currentTheme}
        />
        <SessionCheck>
          <QueryClientProvider client={queryClient}>
            <div
              id="app-analytics-scroll-container"
              className="flex-1 overflow-auto bg-gray-100 px-2 dark:bg-background"
            >
              {children}
            </div>
            <ScrollToTop
                threshold={100}
                position="bottom-right"
                scrollContainer="#app-analytics-scroll-container"
              />
          </QueryClientProvider>
        </SessionCheck>
      </div>
    </div>
  );
}
 