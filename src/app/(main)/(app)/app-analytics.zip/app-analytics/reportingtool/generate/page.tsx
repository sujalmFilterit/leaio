"use client";

import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Filter, Loader2, ChevronDown } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { MultiSelect } from "@/components/ui/multi-select";

import { useRouter, useSearchParams } from "next/navigation";
import { usePackage } from "@/components/mf/PackageContext";
import FilterModal from "@/components/report/filterModal";
import DeliveryOptionsModal from "@/components/report/deliveryoptionsModal";
import ConfirmationDialog from "@/components/report/confirmationDialog";
import ToastContent, { ToastType } from "@/components/mf/ToastContent";
import { useDateRange } from "@/components/mf/DateRangeContext";

// Import hooks
import {
  useGetCategories,
  useGetTemplates,
  useGetTemplateFields,
  useGetDimensionFilters,
  useCreateReport,
  useViewReport,
  useEditReport,
  type CategoryOption,
  type GroupedDimension,
  type DimensionFilter,
  type DeliveryOptions,
  type ReportPayload,
  type CreateReportPayload,
  type ViewReportResponse,
  type TemplateFieldsResponse,
} from "../hooks/useReport";

// Constants
const FILTER_EXCLUDED_TERMS = ["date", "time", "installed_app"];
const CUSTOM_TEMPLATE_NAME = "Custom";
const CUSTOM_RANGE_FREQUENCY = "Custom Range";

// Helper functions
const ensureArray = <T,>(value: T | T[] | null | undefined): T[] => {
  if (Array.isArray(value)) return value;
  if (value !== null && value !== undefined) return [value];
  return [];
};

const shouldShowFilter = (dimensionId: string): boolean => {
  const lowerId = dimensionId?.toLowerCase() || "";
  return !FILTER_EXCLUDED_TERMS.some((term) => lowerId.includes(term));
};

interface CategoryTemplateState {
  template: string;
  dimensions: GroupedDimension[];
  selectedDimensions: string[];
  popoverOpen: boolean;
}

interface ToastData {
  type: ToastType;
  title: string;
  description?: string;
  variant?: "default" | "destructive" | null;
}

const GenerateReportPage = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { selectedPackage } = usePackage();
  const { startDate, endDate } = useDateRange();

  // URL params
  const editId = searchParams.get("id");
  const mode = searchParams.get("mode");
  const isViewMode = mode === "view";
  const isEditMode = mode === "edit";
  const isCloneMode = mode === "clone";

  // Form state
  const [reportName, setReportName] = useState("");
  const [reportCategory, setReportCategory] = useState<string>("summary");
  const [fileType, setFileType] = useState<string>("csv");
  const [frequency, setFrequency] = useState<string | null>(null);
  const [category, setCategory] = useState<string[]>([]);
  const [isDownloadReport, setIsDownloadReport] = useState<boolean | null>(null);

  // Category templates state - dynamic per category
  const [categoryTemplates, setCategoryTemplates] = useState<
    Record<string, CategoryTemplateState>
  >({});

  // Filter state
  const [filterModalOpen, setFilterModalOpen] = useState(false);
  const [selectedItemForFilter, setSelectedItemForFilter] = useState<{
    id: string;
    label: string;
  } | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("");
  const [filterSearch, setFilterSearch] = useState("");
  const [dimensionsFilters, setDimensionsFilters] = useState<DimensionFilter[]>(
    []
  );
  const apiCallInProgressRef = useRef<boolean>(false);

  // Dimension search - debounced for better performance
  const [dimensionSearch, setDimensionSearch] = useState("");
  const [debouncedDimensionSearch, setDebouncedDimensionSearch] = useState("");
  
  // Debounce dimension search to reduce filtering operations
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedDimensionSearch(dimensionSearch);
    }, 150);
    return () => clearTimeout(timer);
  }, [dimensionSearch]);

  // Modal states
  const [thresholdModalOpen, setThresholdModalOpen] = useState(false);
  const [deliveryModalOpen, setDeliveryModalOpen] = useState(false);
  const [deliveryModalType, setDeliveryModalType] = useState<
    "schedule" | "download"
  >("schedule");
  const [confirmationDialogOpen, setConfirmationDialogOpen] = useState(false);

  // Delivery and other data
  const [deliveryData, setDeliveryData] = useState<DeliveryOptions | null>(
    null
  );
  const [metricsThresholds, setMetricsThresholds] = useState<
    Array<{ field: string; operator: string; value: string }>
  >([]);
  const [selectedItemForThreshold, setSelectedItemForThreshold] = useState<{
    id: string;
    label: string;
  } | null>(null);

  // Error states
  const [reportNameError, setReportNameError] = useState<string | null>(null);
  const [dimensionsError, setDimensionsError] = useState<string | null>(null);
  const [categoryError, setCategoryError] = useState<string | null>(null);

  // Toast state
  const [toastData, setToastData] = useState<ToastData | null>(null);

  // API Hooks - Categories
  const {
    data: categoriesData,
    isLoading: isLoadingCategories,
    refetch: refetchCategories,
    error: categoriesError,
  } = useGetCategories(selectedPackage || undefined, !!selectedPackage);
  // Memoize category options for MultiSelect to prevent re-renders
  const categoryOptions = categoriesData?.map((item) => ({
    label: item.label,
    value: item.value,
  })) || [];

  // API Hooks - Templates (per category)
  const {
    data: installTemplatesData,
    isLoading: isLoadingInstallTemplates,
    isFetching: isFetchingInstallTemplates,
    refetch: refetchInstallTemplates,
  } = useGetTemplates(
    selectedPackage,
    "install",
    !!selectedPackage && category.includes("install")
  );

  const {
    data: eventTemplatesData,
    isLoading: isLoadingEventTemplates,
    isFetching: isFetchingEventTemplates,
    refetch: refetchEventTemplates,
  } = useGetTemplates(
    selectedPackage,
    "event",
 !!selectedPackage && category.includes("event")
  );

  // Store template data in a map for dynamic access (memoized to prevent infinite loops)
  const categoryTemplatesDataMap = useMemo<Record<string, string[]>>(() => ({
    install: (Array.isArray(installTemplatesData) ? installTemplatesData : []),
    event: (Array.isArray(eventTemplatesData) ? eventTemplatesData : []),
  }), [installTemplatesData, eventTemplatesData]);

  const categoryTemplatesLoadingMap = useMemo<Record<string, boolean>>(() => ({
    install: isLoadingInstallTemplates || isFetchingInstallTemplates,
    event: isLoadingEventTemplates || isFetchingEventTemplates,
  }), [isLoadingInstallTemplates, isFetchingInstallTemplates, isLoadingEventTemplates, isFetchingEventTemplates]);

  // API Hooks - Template Fields (per category)
  const {
    data: installTemplateFieldsData,
    isLoading: isLoadingInstallTemplateFields,
    refetch: refetchInstallTemplateFields,
  } = useGetTemplateFields(
    categoryTemplates["install"]?.template,
    "install",
    selectedPackage || undefined,
    reportCategory,
    !!categoryTemplates["install"]?.template &&
      category.includes("install") &&
      !!selectedPackage &&
      !!reportCategory &&
      !isViewMode
  );

  const {
    data: eventTemplateFieldsData,
    isLoading: isLoadingEventTemplateFields,
    isFetching: isFetchingEventTemplateFields,
    refetch: refetchEventTemplateFields,
  } = useGetTemplateFields(
    categoryTemplates["event"]?.template,
    "event",
    selectedPackage || undefined,
    reportCategory,
    !!categoryTemplates["event"]?.template &&
      category.includes("event") &&
      !!selectedPackage &&
      !!reportCategory &&
      !isViewMode
  );

  const categoryTemplateFieldsDataMap = useMemo<Record<string, TemplateFieldsResponse | undefined>>(() => ({
    install: installTemplateFieldsData,
    event: eventTemplateFieldsData,
  }), [installTemplateFieldsData, eventTemplateFieldsData]);

  // API Hooks - Filters
  const {
    data: filterData,
    isLoading: isLoadingFilters,
    isFetching: isFetchingFilters,
    refetch: refetchFilters,
    error: filterError,
  } = useGetDimensionFilters(
    selectedItemForFilter?.id,
    selectedPackage || undefined,
    filterCategory || category,
    reportCategory,
    filterSearch,
    filterModalOpen && !!selectedItemForFilter?.id
  );

  const filterLoading = isLoadingFilters || isFetchingFilters;

  // API Hooks - Create, View, Edit (will be called with payload when needed)
  const [createReportPayload, setCreateReportPayload] = useState<CreateReportPayload | undefined>(undefined);
  const {
    data: createReportData,
    isLoading: isCreatingReport,
    isFetching: isFetchingCreateReport,
    refetch: refetchCreateReport,
    error: createReportError,
  } = useCreateReport(createReportPayload, false);

  const [viewReportPayload, setViewReportPayload] = useState<{
    doc_id?: string;
    package_name?: string;
  } | undefined>(undefined);
  const {
    data: viewReportData,
    isLoading: isLoadingViewReport,
    isFetching: isFetchingViewReport,
    refetch: refetchViewReport,
    error: viewReportError,
  } = useViewReport(viewReportPayload, !!viewReportPayload?.doc_id);

  const [editReportPayload, setEditReportPayload] = useState<{
    doc_id?: string;
    package_name?: string;
    update_data?: any;
  } | undefined>(undefined);
  const {
    data: editReportData,
    isLoading: isEditingReport,
    isFetching: isFetchingEditReport,
    refetch: refetchEditReport,
    error: editReportError,
  } = useEditReport(editReportPayload, false);

  // Initialize category templates state - optimized to only add missing categories
  useEffect(() => {
    const missingCategories = category.filter((cat) => !categoryTemplates[cat]);
    if (missingCategories.length > 0) {
      setCategoryTemplates((prev) => {
        const updated = { ...prev };
        missingCategories.forEach((cat) => {
          updated[cat] = {
            template: "",
            dimensions: [],
            selectedDimensions: [],
            popoverOpen: false,
          };
        });
        return updated;
      });
    }
  }, [category, categoryTemplates]);

  // Fetch categories - refetch when package or dates change
  useEffect(() => {
    if (selectedPackage && refetchCategories) {
      refetchCategories();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedPackage, startDate, endDate]); // refetchCategories is stable, no need in deps

  // Set default template when templates are loaded - optimized to batch updates
  useEffect(() => {
    if (editId) return; // Don't set default template in edit/view mode
    
    const updates: Record<string, Partial<CategoryTemplateState>> = {};
    let hasUpdates = false;

    category.forEach((cat) => {
      const templates = categoryTemplatesDataMap[cat] || [];
      const categoryState = categoryTemplates[cat];
      if (
        templates.length > 0 &&
        (!categoryState?.template || categoryState.template === "")
      ) {
        updates[cat] = { template: templates[0] || "" };
        hasUpdates = true;
      }
    });

    if (hasUpdates) {
      setCategoryTemplates((prev) => {
        const updated = { ...prev };
        Object.keys(updates).forEach((cat) => {
          updated[cat] = { ...updated[cat], ...updates[cat] };
        });
        return updated;
      });
    }
  }, [categoryTemplatesDataMap, editId, category, categoryTemplates]);

  // Update dimensions when template fields are loaded - optimized with ref to prevent unnecessary updates
  const prevDimensionsRef = useRef<Record<string, GroupedDimension[]>>({});
  
  useEffect(() => {
    const updates: Record<string, GroupedDimension[]> = {};
    let hasUpdates = false;

    category.forEach((cat) => {
      const fieldsData = categoryTemplateFieldsDataMap[cat];
      
      if (fieldsData?.dimensions) {
        const dimensions = fieldsData.dimensions;
        const prevDimensions = prevDimensionsRef.current[cat] || [];
        
        // Deep comparison without JSON.stringify - compare lengths and first item
        const dimensionsChanged = 
          dimensions.length !== prevDimensions.length ||
          (dimensions.length > 0 && prevDimensions.length > 0 &&
           dimensions[0]?.items?.[0]?.id !== prevDimensions[0]?.items?.[0]?.id);
        
        if (dimensionsChanged) {
          updates[cat] = dimensions;
          prevDimensionsRef.current[cat] = dimensions;
          hasUpdates = true;
        }
      }
    });

    if (hasUpdates) {
      setCategoryTemplates((prev) => {
        const updated = { ...prev };
        Object.keys(updates).forEach((cat) => {
          updated[cat] = { ...updated[cat], dimensions: updates[cat] };
        });
        return updated;
      });
    }
  }, [categoryTemplateFieldsDataMap, category]);

  // Load report data when viewing/editing
  useEffect(() => {
    if (editId && (isEditMode || isCloneMode || isViewMode) && selectedPackage) {
      setViewReportPayload({
        doc_id: editId,
        package_name: selectedPackage,
      });
    }
  }, [editId, isEditMode, isCloneMode, isViewMode, selectedPackage]);

  // Process view report data - optimized to batch all state updates
  const processedViewReportRef = useRef<string | null>(null);
  
  useEffect(() => {
    if (!viewReportData) return;
    
    const response = viewReportData as ViewReportResponse;
    const responseData = response?.data;
    if (!responseData) return;

    // Prevent duplicate processing
    const dataKey = JSON.stringify(responseData);
    if (processedViewReportRef.current === dataKey) return;
    processedViewReportRef.current = dataKey;

    // Extract categories from response
    const categories: string[] = [];
    const categoryDataMap: Record<string, any> = {};

    Object.keys(responseData).forEach((key) => {
      const categoryData = (responseData as any)[key];
      if (categoryData?.category) {
        const catArray = ensureArray(categoryData.category);
        categories.push(...catArray);
        categoryDataMap[key] = categoryData;
      }
    });

    const uniqueCategories = Array.from(new Set(categories));
    const firstCategoryData = Object.values(categoryDataMap)[0];

    if (!firstCategoryData) return;

    // Batch all state updates
    setReportName(firstCategoryData.report_name || "");
    setReportCategory(firstCategoryData.report_type || "summary");
    setFrequency(firstCategoryData.occurence || null);
    setFileType(firstCategoryData.reportFormats || "csv");
    setIsDownloadReport(firstCategoryData.download === "yes");

    if (uniqueCategories.length > 0) {
      setCategory(uniqueCategories);
    }

    // Process category-specific data in batch
    const categoryTemplatesUpdates: Record<string, Partial<CategoryTemplateState>> = {};
    let dimensionsFiltersToSet: DimensionFilter[] = [];
    let deliveryDataToSet: DeliveryOptions | null = null;

    uniqueCategories.forEach((cat) => {
      const catData = categoryDataMap[cat] || responseData[cat as keyof typeof responseData];
      if (!catData) return;

      if (catData.template) {
        categoryTemplatesUpdates[cat] = {
          ...categoryTemplatesUpdates[cat],
          template: catData.template || "",
        };
      }

      if (catData.dimensions?.length > 0) {
        dimensionsFiltersToSet = catData.dimensions;
        const dimensionFields = catData.dimensions.map((dim: DimensionFilter) => dim.field);
        const transformed = catData.dimensions.map((dimension: DimensionFilter) => ({
          label: "",
          items: [{ id: dimension.field, label: dimension.field }],
        }));

        categoryTemplatesUpdates[cat] = {
          ...categoryTemplatesUpdates[cat],
          selectedDimensions: dimensionFields,
          dimensions: transformed,
        };
      }

      if (catData.deliveryOptions) {
        deliveryDataToSet = catData.deliveryOptions;
      }
    });

    // Apply all updates at once
    if (Object.keys(categoryTemplatesUpdates).length > 0) {
      setCategoryTemplates((prev) => {
        const updated = { ...prev };
        Object.keys(categoryTemplatesUpdates).forEach((cat) => {
          updated[cat] = { ...updated[cat], ...categoryTemplatesUpdates[cat] };
        });
        return updated;
      });
    }

    if (dimensionsFiltersToSet.length > 0) {
      setDimensionsFilters(dimensionsFiltersToSet);
    }

    if (deliveryDataToSet) {
      setDeliveryData(deliveryDataToSet);
    }
  }, [viewReportData]);

  // Filter API is already called via hook, this effect just resets the flag
  useEffect(() => {
    if (!filterModalOpen) {
      apiCallInProgressRef.current = false;
    }
  }, [filterModalOpen]);

  // Handlers
  const handleCategoryChange = useCallback(
    (selectedValues: string[]) => {
      if (isViewMode || isEditMode) return;

      setCategory(selectedValues);
      
      if (selectedValues.length > 0) {
        setCategoryError(null);
      }
    },
    [isViewMode, isEditMode]
  );

  const handleTemplateChange = useCallback(
    (categoryType: string, value: string) => {
      setCategoryTemplates((prev) => ({
        ...prev,
        [categoryType]: {
          ...prev[categoryType],
          template: value,
          selectedDimensions: [],
        },
      }));
    },
    []
  );

  const handleDimensionSelect = useCallback(
    (categoryType: string, value: string) => {
      setCategoryTemplates((prev) => {
        const categoryState = prev[categoryType] || {
          template: "",
          dimensions: [],
          selectedDimensions: [],
          popoverOpen: false,
        };
        const currentSelected = categoryState.selectedDimensions || [];
        let newSelected;
        if (currentSelected.includes(value)) {
          newSelected = currentSelected.filter((dim) => dim !== value);
        } else {
          newSelected = [...currentSelected, value];
        }

        if (newSelected.length > 0) {
          setDimensionsError(null);
        }

        return {
          ...prev,
          [categoryType]: {
            ...categoryState,
            selectedDimensions: newSelected,
          },
        };
      });
    },
    []
  );

  const handleFilterClick = useCallback(
    (item: { id: string; label: string }, categoryType: string) => {
      setSelectedItemForFilter(item);
      setFilterCategory(categoryType);
      setFilterSearch("");
      setFilterModalOpen(true);
    },
    []
  );

  const handleFilterSave = useCallback((dimensionData: DimensionFilter) => {
    setDimensionsFilters((prev) => {
      const existingIndex = prev.findIndex(
        (dim) => dim.field === dimensionData.field
      );

      if (existingIndex !== -1) {
        // Only update if data actually changed
        if (JSON.stringify(prev[existingIndex]) === JSON.stringify(dimensionData)) {
          return prev;
        }
        const updatedFilters = [...prev];
        updatedFilters[existingIndex] = dimensionData;
        return updatedFilters;
      } else {
        return [...prev, dimensionData];
      }
    });
  }, []);

  const handleSaveThreshold = useCallback(
    (thresholdData: {
      field: string;
      operator: string;
      value: string;
    }) => {
      setMetricsThresholds((prev) => {
        const existingIndex = prev.findIndex(
          (metric) => metric.field === thresholdData.field
        );

        if (existingIndex !== -1) {
          // Only update if data actually changed
          if (
            prev[existingIndex].operator === thresholdData.operator &&
            prev[existingIndex].value === thresholdData.value
          ) {
            return prev;
          }
          const updatedThresholds = [...prev];
          updatedThresholds[existingIndex] = thresholdData;
          return updatedThresholds;
        } else {
          return [...prev, thresholdData];
        }
      });
    },
    []
  );

  const handleSettingsClick = useCallback(
    (item: { id: string; label: string }) => {
      setSelectedItemForThreshold(item);
      setThresholdModalOpen(true);
    },
    []
  );

  // Validation
  const validateForm = useCallback((): boolean => {
    let isValid = true;

    if (!reportName.trim()) {
      setReportNameError("Report name is mandatory.");
      isValid = false;
    }

    if (category.length === 0) {
      setCategoryError("Please select at least one category");
      isValid = false;
    }

    // Validate dimensions for each category with Custom template
    category.forEach((cat) => {
      const categoryState = categoryTemplates[cat];
      if (
        categoryState?.template === CUSTOM_TEMPLATE_NAME &&
        (!categoryState.selectedDimensions ||
          categoryState.selectedDimensions.length === 0)
      ) {
        setDimensionsError("Please select at least one dimension");
        isValid = false;
      }
    });

    return isValid;
  }, [reportName, category, categoryTemplates]);

  // Create dimensions payload for a category
  const createDimensionsPayload = useCallback(
    (categoryType: string): DimensionFilter[] => {
      const categoryState = categoryTemplates[categoryType];
      if (!categoryState) return [];

      let dimensionsForPayload: DimensionFilter[] = [];

      if (categoryState.template === CUSTOM_TEMPLATE_NAME) {
        const relevantDimensions = categoryState.selectedDimensions || [];
        dimensionsForPayload = relevantDimensions.map((dimensionId) => {
          const existingFilter = dimensionsFilters.find(
            (filter) => filter.field === dimensionId
          );

          return existingFilter || { field: dimensionId, value: [] };
        });
      } else {
        // For non-custom templates, include all dimensions
        const allDimensions: Array<{ id: string; label: string }> = [];
        (categoryState.dimensions || []).forEach((group: GroupedDimension) => {
          group.items.forEach((item: { id: string; label: string }) => {
            allDimensions.push(item);
          });
        });

        dimensionsForPayload = allDimensions.map((dimension) => {
          const existingFilter = dimensionsFilters.find(
            (filter) => filter.field === dimension.id
          );

          return {
            field: dimension.id,
            value: existingFilter?.value || [],
          };
        });
      }

      return dimensionsForPayload;
    },
    [categoryTemplates, dimensionsFilters]
  );

  // Create report payload helper function
  const buildCreateReportPayload = useCallback(
    (data: DeliveryOptions): CreateReportPayload => {
      const finalPayload: CreateReportPayload = {};

      category.forEach((cat) => {
        const categoryState = categoryTemplates[cat];
        if (!categoryState?.template) return;

        const payload: ReportPayload = {
          report_name: reportName,
          occurance: frequency || undefined,
          package_name: selectedPackage || "",
          dimensions: createDimensionsPayload(cat),
          reportFormats: fileType,
          report_type: reportCategory,
          deliveryOptions: (data as any)?.[cat] || data,
          download: deliveryModalType === "download" ? "yes" : "no",
          template: categoryState.template,
          category: [cat],
        };

        if (frequency === CUSTOM_RANGE_FREQUENCY) {
          payload.start_date = data?.dateRange?.startDate;
          payload.end_date = data?.dateRange?.endDate;
        }

        (finalPayload as any)[cat] = payload;
      });

      return finalPayload;
    },
    [
      category,
      categoryTemplates,
      reportName,
      frequency,
      selectedPackage,
      fileType,
      reportCategory,
      deliveryModalType,
      createDimensionsPayload,
    ]
  );

  const handleModalSubmit = useCallback(
    (data: DeliveryOptions) => {
      setDeliveryData(data);

      if (editId && isEditMode) {
        const updateData: Record<string, ReportPayload> = {};
        category.forEach((cat) => {
          const categoryState = categoryTemplates[cat];
          if (!categoryState?.template) return;

          const payload: ReportPayload = {
            report_name: reportName,
            occurence: frequency || undefined,
            package_name: selectedPackage || "",
            dimensions: createDimensionsPayload(cat),
            reportFormats: fileType,
            report_type: reportCategory,
            deliveryOptions: (data as any)?.[cat] || data,
            download: deliveryModalType === "download" ? "yes" : "no",
            template: categoryState.template,
            category: cat,
          };

          if (frequency === CUSTOM_RANGE_FREQUENCY) {
            payload.start_date = data?.dateRange?.startDate;
            payload.end_date = data?.dateRange?.endDate;
          }

          updateData[cat] = payload;
        });

          const updatePayload = {
            doc_id: editId,
            package_name: selectedPackage,
            update_data: updateData,
          };

          setEditReportPayload(updatePayload);
          // Trigger refetch to execute the edit (use requestAnimationFrame for better performance)
          requestAnimationFrame(() => {
            if (refetchEditReport) {
              refetchEditReport();
            }
          });
      } else {
        const finalPayload = buildCreateReportPayload(data);
        setCreateReportPayload(finalPayload);
        // Trigger refetch to execute the create (use requestAnimationFrame for better performance)
        requestAnimationFrame(() => {
          if (refetchCreateReport) {
            refetchCreateReport();
          }
        });
      }

      setDeliveryModalOpen(false);
    },
    [
      editId,
      isEditMode,
      category,
      categoryTemplates,
      reportName,
      frequency,
      selectedPackage,
      fileType,
      reportCategory,
      deliveryModalType,
      createDimensionsPayload,
      buildCreateReportPayload,
      refetchEditReport,
      refetchCreateReport,
    ]
  );

  const handleConfirmation = useCallback(
    (action: "cloud" | "email" | "download") => {
      setConfirmationDialogOpen(false);
      if (action === "cloud" || action === "email") {
        setDeliveryModalType("download");
        setDeliveryModalOpen(true);
      } else {
        if (deliveryData) {
          // Similar logic to handleModalSubmit but for download
          handleModalSubmit(deliveryData);
        }
      }
    },
    [deliveryData, handleModalSubmit]
  );

  const handleDownloadClick = useCallback(() => {
    if (!validateForm()) return;

    setDeliveryModalType("download");
    setDeliveryModalOpen(true);
  }, [validateForm]);

  const handleScheduleClick = useCallback(() => {
    if (!validateForm()) return;

    setDeliveryModalType("schedule");
    setDeliveryModalOpen(true);
  }, [validateForm]);

  // Handle API success/error
  useEffect(() => {
    if (createReportData) {
      const data = createReportData as { status?: string };
      if (data?.status === "success") {
        setToastData({
          type: "success",
          title: "Success",
          description: "Report created successfully!",
          variant: "default",
        });
        router.push("/app-analytics/reportingtool/report");
      }
    }
  }, [createReportData, router]);

  useEffect(() => {
    if (editReportData) {
      const data = editReportData as { status?: string };
      if (data?.status === "success") {
        setToastData({
          type: "success",
          title: "Success",
          description: "Report updated successfully!",
          variant: "default",
        });
        router.push("/app-analytics/reportingtool/report");
      }
    }
  }, [editReportData, router]);

  // Loading state - memoized to prevent unnecessary recalculations
  const isLoading = useMemo(
    () =>
      isCreatingReport ||
      isFetchingCreateReport ||
      isLoadingViewReport ||
      isFetchingViewReport ||
      isEditingReport ||
      isFetchingEditReport,
    [
      isCreatingReport,
      isFetchingCreateReport,
      isLoadingViewReport,
      isFetchingViewReport,
      isEditingReport,
      isFetchingEditReport,
    ]
  );

  return (
    <>
      {isLoading ? (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="p-6">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        </div>
      ) : (
        <div className="bg-white p-4 mt-2 rounded-md">
          {toastData && (
            <ToastContent
              type={toastData.type}
              title={toastData.title}
              description={toastData.description}
              variant={toastData.variant}
            />
          )}
          <div className="mb-6 flex items-center justify-between">
            <h1 className="text-xl font-bold">
              {isViewMode
                ? "View Report"
                : isEditMode
                  ? "Edit Report"
                  : "Generate New Report"}
            </h1>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-4 gap-4 items-center">
              {/* Report Name */}
              <div className="space-y-2">
                <Label>Report Name</Label>
                <Input
                  placeholder="Enter Report Name"
                  className="dark:text-white"
                  value={reportName}
                  onChange={(e) => {
                    setReportName(e.target.value);
                    setReportNameError(null);
                  }}
                  disabled={isViewMode || isEditMode}
                />
                {reportNameError && (
                  <p className="text-sm text-red-500">{reportNameError}</p>
                )}
              </div>

              {/* Category MultiSelect */}
              <div className="space-y-2">
                <Label>Category</Label>
                {isLoadingCategories ? (
                  <div className="flex items-center justify-center h-10 border border-input rounded-md">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  </div>
                ) : (
                  <MultiSelect
                    options={categoryOptions}
                    onValueChange={handleCategoryChange}
                    defaultValue={category}
                    placeholder="Select Category"
                    disabled={isViewMode || isEditMode}
                    className="w-full"
                  />
                )}
                {categoryError && (
                  <p className="text-sm text-red-500">{categoryError}</p>
                )}
              </div>

              {/* File Type */}
              <div className="space-y-2">
                <Label>File Type</Label>
                <div className="flex gap-4">
                  {["csv", "xlsx", "parquet"].map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id={type}
                        name="fileType"
                        value={type}
                        checked={fileType === type}
                        onChange={(e) => setFileType(e.target.value)}
                        className="h-4 w-4 border-gray-300 accent-primary focus:ring-primary"
                        disabled={isViewMode || isEditMode}
                      />
                      <Label htmlFor={type} className="capitalize">
                        {type}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Report Category */}
              <div className="space-y-2">
                <Label>Report Category</Label>
                <div className="flex gap-4">
                  {["summary", "transactional"].map((type) => (
                    <div key={type} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id={type}
                        name="reportCategory"
                        value={type}
                        checked={reportCategory === type}
                        onChange={(e) =>
                          setReportCategory(e.target.value as "summary" | "transactional")
                        }
                        className="h-4 w-4 border-gray-300 accent-primary focus:ring-primary"
                        disabled={isViewMode || isEditMode}
                      />
                      <Label htmlFor={type} className="capitalize">
                        {type}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Dynamic Category Sections */}
            <div className="flex gap-x-4 w-full">
              {category.map((cat) => {
                const categoryState = categoryTemplates[cat] || {
                  template: "",
                  dimensions: [],
                  selectedDimensions: [],
                  popoverOpen: false,
                };
                const templates = categoryTemplatesDataMap[cat] || [];
                const isLoadingTemplates = categoryTemplatesLoadingMap[cat] || false;
                
                // Filter dimensions for this category (using debounced search)
                const filteredDimensions = (() => {
                  if (!debouncedDimensionSearch) return categoryState.dimensions;
                  const searchLower = debouncedDimensionSearch.toLowerCase();
                  return categoryState.dimensions
                    .map((group: GroupedDimension) => ({
                      ...group,
                      items: group.items.filter((item: { id: string; label: string }) =>
                        item.label.toLowerCase().includes(searchLower)
                      ),
                    }))
                    .filter((group) => group.items.length > 0);
                })();

                return (
                  <div
                    key={cat}
                    className="w-1/2 border border-gray-300 rounded-md p-4"
                  >
                    <div className="space-y-4">
                      {/* Template Select */}
                      <div className="space-y-2">
                        <Label>{cat.charAt(0).toUpperCase() + cat.slice(1)} Template</Label>
                        <Select
                          value={categoryState.template}
                          onValueChange={(value) =>
                            handleTemplateChange(cat, value)
                          }
                          disabled={isViewMode}
                        >
                          <SelectTrigger>
                            <SelectValue
                              placeholder={`Choose ${cat} Template`}
                            />
                          </SelectTrigger>
                          <SelectContent>
                            {isLoadingTemplates ? (
                              <div className="flex justify-center items-center p-2">
                                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                              </div>
                            ) : (
                              templates.map((template) => (
                                <SelectItem
                                  key={template}
                                  value={template}
                                  className="text-sm leading-5"
                                >
                                  {template}
                                </SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Dimensions */}
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold">
                          {cat.charAt(0).toUpperCase() + cat.slice(1)} Dimensions
                        </h3>
                      </div>

                      {categoryState.template === CUSTOM_TEMPLATE_NAME && (
                        <Popover
                          open={categoryState.popoverOpen}
                          onOpenChange={(open) =>
                            setCategoryTemplates((prev) => ({
                              ...prev,
                              [cat]: {
                                ...prev[cat],
                                popoverOpen: open,
                              },
                            }))
                          }
                        >
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              role="combobox"
                              className="w-full justify-between"
                              disabled={isViewMode}
                            >
                              Select {cat.charAt(0).toUpperCase() + cat.slice(1)} Dimensions
                              <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-full p-0">
                            <div className="p-2">
                              <Input
                                type="text"
                                placeholder="Search dimensions..."
                                className="mb-2"
                                value={dimensionSearch}
                                onChange={(e) =>
                                  setDimensionSearch(e.target.value)
                                }
                              />
                              <div className="max-h-[300px] overflow-y-auto">
                                {filteredDimensions.map((group) => (
                                    <div key={group.label} className="mb-4">
                                      <div className="mb-2 px-2 text-sm font-medium text-gray-700">
                                        {group.label}
                                      </div>
                                      {group.items.map((item: { id: string; label: string }) => (
                                        <div
                                          key={item.id}
                                          className="flex cursor-pointer items-center justify-between rounded-md px-2 py-1.5"
                                        >
                                          <div className="flex items-center gap-2">
                                            <Checkbox
                                              id={`dimension-${cat}-${item.id}`}
                                              checked={(
                                                categoryState.selectedDimensions ||
                                                []
                                              ).includes(item.id)}
                                              onCheckedChange={() =>
                                                handleDimensionSelect(cat, item.id)
                                              }
                                            />
                                            <Label
                                              htmlFor={`dimension-${cat}-${item.id}`}
                                              className="cursor-pointer"
                                              onClick={() =>
                                                handleDimensionSelect(cat, item.id)
                                              }
                                            >
                                              {item.label}
                                            </Label>
                                          </div>
                                        </div>
                                      ))}
                                    </div>
                                  ))}
                              </div>
                            </div>
                          </PopoverContent>
                        </Popover>
                      )}

                      {dimensionsError && (
                        <p className="text-sm text-red-500">{dimensionsError}</p>
                      )}

                      {/* Display dimensions */}
                      {categoryState.template === CUSTOM_TEMPLATE_NAME &&
                      (!categoryState.selectedDimensions ||
                        categoryState.selectedDimensions.length === 0) ? (
                        <div className="mt-2 flex h-20 items-center justify-center rounded-md border border-dashed border-gray-300">
                          <p className="text-sm text-gray-500">
                            Select dimensions to view them here
                          </p>
                        </div>
                      ) : (
                        <div className="mt-2 max-h-[200px] overflow-y-auto rounded-md border border-gray-300 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                          {categoryState.dimensions.map((group) => {
                            // Calculate group items (optimized inline)
                            const groupItems =
                              categoryState.template === CUSTOM_TEMPLATE_NAME
                                ? group.items.filter((item) =>
                                    (categoryState.selectedDimensions || []).includes(item.id)
                                  )
                                : group.items;

                            if (groupItems.length === 0) return null;

                            return (
                              <div key={group.label} className="space-y-1 p-2">
                                <div className="">{group.label}</div>
                                {groupItems.map((item: { id: string; label: string }) => (
                                  <div
                                    key={item.id}
                                    className="flex items-center justify-between"
                                  >
                                    <div
                                      className={`flex items-center gap-2 ${
                                        categoryState.template !==
                                        CUSTOM_TEMPLATE_NAME
                                          ? "justify-between w-full"
                                          : ""
                                      }`}
                                    >
                                      {categoryState.template ===
                                      CUSTOM_TEMPLATE_NAME ? (
                                        <>
                                          <Checkbox
                                            id={item.id}
                                            checked={true}
                                            onClick={() =>
                                              handleDimensionSelect(cat, item.id)
                                            }
                                          />
                                          <Label htmlFor={item.id}>
                                            {item.label}
                                          </Label>
                                        </>
                                      ) : (
                                        <Label htmlFor={item.id}>
                                          {item.label}
                                        </Label>
                                      )}
                                    </div>

                                    {shouldShowFilter(item.id) && (
                                      <Filter
                                        className="h-4 w-4 cursor-pointer text-primary"
                                        onClick={() =>
                                          handleFilterClick(item, cat)
                                        }
                                      />
                                    )}
                                  </div>
                                ))}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <Button
              onClick={() => {
                router.push("/app-analytics/reportingtool/report");
              }}
              className="text-white bg-primary hover:bg-primary"
            >
              Cancel
            </Button>
            <Button
              onClick={handleScheduleClick}
              className="text-white bg-primary hover:bg-primary"
              disabled={
                (isViewMode || isEditMode || isCloneMode) &&
                isDownloadReport === true
              }
            >
              Schedule
            </Button>
            <Button
              onClick={handleDownloadClick}
              className="text-white bg-primary hover:bg-primary"
              disabled={
                (isViewMode || isEditMode || isCloneMode) &&
                isDownloadReport === false
              }
            >
              Download
            </Button>
          </div>

          <ConfirmationDialog
            isOpen={confirmationDialogOpen}
            onClose={() => setConfirmationDialogOpen(false)}
            onConfirm={handleConfirmation}
          />

          <FilterModal
            isOpen={filterModalOpen}
            onClose={() => {
              setFilterModalOpen(false);
              setSelectedItemForFilter(null);
              setFilterSearch("");
              apiCallInProgressRef.current = false;
            }}
            selectedItem={selectedItemForFilter}
            onSave={handleFilterSave}
            filterData={filterData}
            filterloading={filterLoading}
            savedFilters={dimensionsFilters}
            mode={mode || ""}
            onSearchChange={setFilterSearch}
            searchValue={filterSearch}
          />

          <DeliveryOptionsModal
            category={category.join(",")}
            isOpen={deliveryModalOpen}
            onClose={() => {
              setDeliveryModalOpen(false);
              setDeliveryData(null);
            }}
            type={deliveryModalType}
            onSubmit={handleModalSubmit}
            defaultData={deliveryData}
            mode={mode || ""}
            frequency={frequency || undefined}
            onFrequencyChange={(val) => setFrequency(val || null)}
          />
        </div>
      )}
    </>
  );
};

export default GenerateReportPage;
