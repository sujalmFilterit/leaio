"use client";

import { useApi } from "@/hooks/api/api_base";

// Type definitions
export interface CategoryOption {
  value: string;
  label: string;
}

export interface DimensionItem {
  id: string;
  label: string;
}

export interface GroupedDimension {
  label: string;
  items: DimensionItem[];
}

export interface DimensionFilter {
  field: string;
  value: string[];
}

export interface MetricThreshold {
  field: string;
  operator: string;
  value: string;
}

export interface DeliveryOptions {
  email?: {
    status?: boolean;
    to?: string[];
    mail_id_list?: string[];
    install_to?: string[];
    install_mail_id_list?: string[];
    event_to?: string[];
    event_mail_id_list?: string[];
  };
  cloud?: {
    status?: boolean;
    bucket_name?: string;
    path?: string;
  };
  dateRange?: {
    startDate?: string;
    endDate?: string;
  };
  install?: DeliveryOptions;
  event?: DeliveryOptions;
}

export interface ReportPayload {
  report_name: string;
  occurence?: string;
  occurance?: string;
  package_name: string;
  dimensions: DimensionFilter[];
  reportFormats: string;
  report_type: string;
  deliveryOptions?: DeliveryOptions;
  download: "yes" | "no";
  template: string;
  category: string | string[];
  start_date?: string;
  end_date?: string;
}

export interface CreateReportPayload {
  install?: ReportPayload;
  event?: ReportPayload
}

export interface ViewReportResponse {
  data?: {
    install?: ReportData;
    event?: ReportData;
  };
}

export interface ReportData {
  report_name?: string;
  report_type?: string;
  occurence?: string;
  reportFormats?: string;
  download?: string;
  template?: string;
  category?: string | string[];
  dimensions?: DimensionFilter[];
  deliveryOptions?: DeliveryOptions;
  start_date?: string;
  end_date?: string;
}

export interface TemplateFieldsResponse {
  dimensions?: GroupedDimension[];
  metrics?: any[];
}

export interface FilterResponse {
  data?: any[];
  options?: any[];
}

export interface CreateReportResponse {
  status?: string;
  message?: string;
}

export interface EditReportResponse {
  status?: string;
  message?: string;
}

// API Base URL
const REPORT_API_BASE = process.env.NEXT_PUBLIC_APP_PERF + "reporting_tool";

/**
 * Fetch categories for report
 */
export const useGetCategories = (
  packageName?: string,
  enabled: boolean = false
) => {
  return useApi<CategoryOption[]>(
    `${REPORT_API_BASE}/get_category`,
    "POST",
    {
      package_name: packageName,
    },
    {
      queryKey: ["report-categories", packageName || ""] as const,
      enabled,
    }
  );
};

/**
 * Fetch templates for a specific category
 */
export const useGetTemplates = (
  packageName?: string,
  category?: string,
  enabled: boolean = false
) => {
  return useApi<string[]>(
    `${REPORT_API_BASE}/get_template`,
    "POST",
    {
      package_name: packageName,
      category: category,
    },
    {
      queryKey: ["report-templates", packageName || "", category || ""] as const,
      enabled,
    }
  );
};

/**
 * Fetch template fields (dimensions and metrics) for a template
 */
export const useGetTemplateFields = (
  template?: string,
  category?: string,
  packageName?: string,
  reportType?: string,
  enabled: boolean = false
) => {
  return useApi<TemplateFieldsResponse>(
    `${REPORT_API_BASE}/get_template_fields`,
    "POST",
    {
      template: template,
      category: category,
      package_name: packageName,
      report_type: reportType,
    },
    {
      queryKey: ["template-fields", template || "", category || "", packageName || "", reportType || ""] as const,
      enabled,
    }
  );
};

/**
 * Fetch filter options for a dimension
 */
export const useGetDimensionFilters = (
  dimensionId?: string,
  packageName?: string,
  category?: string | string[],
  reportType?: string,
  search?: string,
  enabled: boolean = false
) => {
  const categoryParam = Array.isArray(category)
    ? category.join(",")
    : category || "";

  return useApi<FilterResponse>(
    `${REPORT_API_BASE}/fields/filters/${dimensionId || ""}/`,
    "POST",
    {
      package_name: packageName,
      category: categoryParam,
      report_type: reportType,
      search: search || "",
    },
    {
      queryKey: ["dimension-filters", dimensionId || "", packageName || "", categoryParam, reportType || "", search || ""] as const,
      enabled,
    }
  );
};

/**
 * Create a new report
 */
export const useCreateReport = (
  payload?: CreateReportPayload,
  enabled: boolean = false
) => {
  return useApi<CreateReportResponse>(
    `${REPORT_API_BASE}/create_report`,
    "POST",
    payload,
    {
      queryKey: ["create-report", payload ? JSON.stringify(payload) : ""] as const,
      enabled,
    }
  );
};

/**
 * View/Get an existing report
 */
export const useViewReport = (
  payload?: {
    doc_id?: string;
    package_name?: string;
  },
  enabled: boolean = false
) => {
  return useApi<ViewReportResponse>(
    `${REPORT_API_BASE}/view_report`,
    "POST",
    payload,
    {
      queryKey: ["view-report", payload?.doc_id || "", payload?.package_name || ""] as const,
      enabled,
    }
  );
};

/**
 * Edit/Update an existing report
 */
export const useEditReport = (
  payload?: {
    doc_id?: string;
    package_name?: string;
    update_data?: any;
  },
  enabled: boolean = false
) => {
  return useApi<EditReportResponse>(
    `${REPORT_API_BASE}/edit_report`,
    "POST",
    payload,
    {
      queryKey: ["edit-report", payload?.doc_id || "", payload?.package_name || ""] as const,
      enabled,
    }
  );
};
