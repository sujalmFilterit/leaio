"use client";
import ProgressBarChart from "@/components/mf/charts/ProgressBarChart";
import { Card, CardContent } from "@/components/ui/card";
import React, {
  useRef,
  useState,
  useEffect,
  useMemo,
} from "react";
import domToImage from "dom-to-image";
import { downloadURI } from "@/lib/utils";
import StackedBarWithLine1 from "@/components/mf/charts/StackedBarwithLine";
import StackedBarChart from "@/components/mf/charts/stackedBarChart";
import ResizableTable from "@/components/mf/ReportingToolTable";
import { usePackage } from "@/components/mf/PackageContext";
import { useDateRange } from "@/components/mf/DateRangeContext";
import {
  usePublishersFilter,
  useEventTypeFilterExtended,
  useCleanPublishers,
  useFraudulentPublishers,
  useVtaCtaPublisherSummary,
  useStateWisePublisher,
  useMakeModelWisePublisher,
  usePublisherWiseOsDetails,
  useCvr,
  useIncentSamples,
  type PublisherApiResponse,
  type FilterPayload,
} from "../hooks/useDashboard";
import { Filter } from "@/components/mf/Filters/Filter";

import { MFSingleSelect } from "@/components/mf/MFSingleSelect";
import MultipleSelect from "@/components/ui/multiple-select";
import { onExpand } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Loader2, BarChart3, TrendingUp } from "lucide-react";
import { MdFileDownload } from "react-icons/md";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

const Analytics = () => {
  const cardRefs = useRef<Record<string, HTMLElement | null>>({});
  const { selectedPackage, isPackageLoading } = usePackage();
  const { startDate, endDate } = useDateRange();

  const [selectedType] = useState<"install" | "event">("install");
  const [selectedPublisher, setSelectedPublisher] = useState<string>("");

  // Add CVR filter state
  const [cvrPublisherFilter, setCvrPublisherFilter] = useState<string[]>([]);
  const [cvrEventTypeFilter, setCvrEventTypeFilter] = useState<string[]>([]);

  // Add CVR data state (kept as state for pagination)
  const [cvrTotalPages, setCvrTotalPages] = useState(1);
  const [cvrTotalRecords, setCvrTotalRecords] = useState(0);

  // Add incent samples publisher filter state
  const [incentSamplesPublisherFilter, setIncentSamplesPublisherFilter] =
    useState<string[]>([]);
  const [
    debouncedIncentSamplesPublisherFilter,
    setDebouncedIncentSamplesPublisherFilter,
  ] = useState<string[]>(["all"]);

  // Add search and pagination state
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [isSearching, setIsSearching] = useState(false);

  // Add separate search states for VTA & CTA table
  const [vtaCtaSearchTerm, setVtaCtaSearchTerm] = useState("");
  // VTA & CTA table columns
  const vtaCtaColumns = [
    {
      title: "Publisher Name",
      key: "publisher_name",
      render: (item: any) => item.publisher_name || "",
    },
    {
      title: "Total Installs",
      key: "total_installs",
      render: (item: any) =>
        new Intl.NumberFormat("en-US").format(item.total_installs) || "0",
    },
    {
      title: "VTA",
      key: "vta",
      render: (item: any) => item.vta?.toLocaleString() || "0",
    },
    {
      title: "VTA %",
      key: "percent_vta",
      render: (item: any) => item.percent_vta || "0%",
    },
    {
      title: "CTA",
      key: "cta",
      render: (item: any) =>
        new Intl.NumberFormat("en-US").format(item.cta) || "0",
    },
    {
      title: "CTA %",
      key: "percent_cta",
      render: (item: any) => item.percent_cta || "0%",
    },
  ];

  // Base payload for API calls
  const basePayload = useMemo<FilterPayload | undefined>(() => {
    if (!selectedPackage || !startDate || !endDate || isPackageLoading) {
      return undefined;
    }
    return {
      package_name: selectedPackage,
      start_date: startDate,
      end_date: endDate,
    };
  }, [selectedPackage, startDate, endDate, isPackageLoading]);

  // Publishers Filter API
  const publishersFilterApi = usePublishersFilter(
    selectedType,
    basePayload,
    !!basePayload
  );

  // Extract publisher data directly
  const existingPublisherdata = useMemo<PublisherApiResponse>(
    () => publishersFilterApi?.data || { Affiliate: [], "Whitelisted Publisher": [] },
    [publishersFilterApi?.data]
  );

  // Initialize selected publisher
  useEffect(() => {
    if (
      existingPublisherdata?.Affiliate &&
      existingPublisherdata.Affiliate.length > 0 &&
      !selectedPublisher
    ) {
      setSelectedPublisher(existingPublisherdata.Affiliate[0]);
      }
  }, [existingPublisherdata?.Affiliate, selectedPublisher]);

  // Effect to initialize incent samples publisher filter when publishers are loaded
  useEffect(() => {
    if (
      existingPublisherdata?.Affiliate &&
      existingPublisherdata.Affiliate.length > 0
    ) {
      // Only update if current value is different from ["all"] to prevent unnecessary re-renders
      setIncentSamplesPublisherFilter((prev) => {
        if (JSON.stringify(prev) === JSON.stringify(["all"])) {
          return prev; // Return same reference if value is already ["all"]
        }
        return ["all"];
      });
      setDebouncedIncentSamplesPublisherFilter((prev) => {
        if (JSON.stringify(prev) === JSON.stringify(["all"])) {
          return prev; // Return same reference if value is already ["all"]
        }
        return ["all"];
      });
    }
  }, [existingPublisherdata.Affiliate]);

  // Event Type Filter API - Always enabled for CVR section
  const eventTypeFilterApi = useEventTypeFilterExtended(
    "event",
    basePayload,
    !!basePayload
  );

  // Extract event type data directly
  const existingEventTypeData = useMemo<string[]>(
    () => (Array.isArray(eventTypeFilterApi?.data) ? eventTypeFilterApi.data : []),
    [eventTypeFilterApi?.data]
  );

  // Initialize CVR event type filter with all event types
  useEffect(() => {
    if (existingEventTypeData.length > 0 && cvrEventTypeFilter.length === 0) {
      setCvrEventTypeFilter(existingEventTypeData);
    }
  }, [existingEventTypeData, cvrEventTypeFilter.length]);

  // Create filter structure for CVR section
  const cvrFilter = useMemo(() => {
    const totalPublishers = Object.values(existingPublisherdata || {}).flat()
      .length;
    const selectedPublishers =
      !cvrPublisherFilter ||
      cvrPublisherFilter.length === 0 ||
      cvrPublisherFilter?.includes("all")
        ? totalPublishers
        : (cvrPublisherFilter?.length ?? totalPublishers);

    const publishersFilter = {
      Publishers: {
        filters: Object.entries(existingPublisherdata || {}).map(
          ([group, publishers]) => ({
            label: group,
            checked: true,
            subItems:
              (publishers as string[])?.map((publisher: string) => ({
                label: publisher,
                checked:
                  !cvrPublisherFilter ||
                  cvrPublisherFilter.length === 0 ||
                  cvrPublisherFilter?.includes("all") ||
                  cvrPublisherFilter?.includes(publisher),
              })) || [],
          })
        ),
        isSelectAll:
          !cvrPublisherFilter ||
          cvrPublisherFilter.length === 0 ||
          cvrPublisherFilter.includes("all") ||
          cvrPublisherFilter?.length === totalPublishers,
        selectedCount: selectedPublishers,
        loading: publishersFilterApi?.isLoading,
      },
    };

    return { publishersFilter };
  }, [
    existingPublisherdata,
    cvrPublisherFilter,
    publishersFilterApi?.isLoading,
  ]);

  // Create filter structure for Incent Samples section
  const incentSamplesFilter = useMemo(() => {
    const totalPublishers = Object.values(existingPublisherdata || {}).flat()
      .length;
    const selectedPublishers = incentSamplesPublisherFilter?.includes("all")
      ? totalPublishers
      : (incentSamplesPublisherFilter?.length ?? totalPublishers);

    const publishersFilter = {
      Publishers: {
        filters: Object.entries(existingPublisherdata || {}).map(
          ([group, publishers]) => ({
            label: group,
            checked: true,
            subItems:
              (publishers as string[])?.map((publisher: string) => ({
              label: publisher,
              checked:
                  incentSamplesPublisherFilter?.includes("all") ||
                  incentSamplesPublisherFilter?.includes(publisher) ||
                  !incentSamplesPublisherFilter ||
                  incentSamplesPublisherFilter.length === 0,
              })) || [],
          })
        ),
        isSelectAll:
          !incentSamplesPublisherFilter ||
          incentSamplesPublisherFilter.length === 0 ||
          incentSamplesPublisherFilter.includes("all") ||
          incentSamplesPublisherFilter?.length === totalPublishers,
        selectedCount: selectedPublishers,
        loading: publishersFilterApi?.isLoading,
      },
    };

    return { publishersFilter };
  }, [
    existingPublisherdata,
    incentSamplesPublisherFilter,
    publishersFilterApi?.isLoading,
  ]);

  // Handle CVR filter change
  const handleCvrFilterChange = (filterState: any) => {
    if (filterState?.Publishers) {
      const publisherPayload = {
        publishers: filterState.Publishers.isSelectAll
          ? ["all"]
          : [
              ...(filterState.Publishers.filters?.Affiliate || []),
              ...(filterState.Publishers.filters?.["Whitelisted Publisher"] ||
                []),
            ],
      };
      setCvrPublisherFilter(publisherPayload.publishers);
    }
  };

  // Handle event type selection with "all" logic
  const handleEventTypeChange = (values: string[]) => {
    const allEventTypes = existingEventTypeData;
    if (values.length === 0 || values.length === allEventTypes.length) {
      setCvrEventTypeFilter(["all"]);
    } else {
      setCvrEventTypeFilter(values);
    }
  };

  // Convert Affiliate publishers to MFSingleSelect format
  const publisherItems = useMemo(() => {
    return (existingPublisherdata?.Affiliate || []).map((publisher) => ({
      title: publisher,
      value: publisher,
    }));
  }, [existingPublisherdata?.Affiliate]);

  // Handle publisher selection
  const handlePublisherChange = (value: string) => {
    setSelectedPublisher(value);
  };

  // API calls - destructure data and loading directly
  const {
    data: cleanInstallData,
    isLoading: isCleanInstallLoading,
  } = useCleanPublishers(selectedType, basePayload, !!basePayload);

  const {
    data: fraudulentInstallData,
    isLoading: isFraudulentInstallLoading,
  } = useFraudulentPublishers(selectedType, basePayload, !!basePayload);

  const {
    data: cleanEventData,
    isLoading: isCleanEventLoading,
  } = useCleanPublishers(
    selectedType,
    basePayload,
    !!basePayload && selectedType === "event"
  );

  const {
    data: fraudulentEventData,
    isLoading: isFraudulentEventLoading,
  } = useFraudulentPublishers(
    selectedType,
    basePayload,
    !!basePayload && selectedType === "event"
  );

  // API call for VTA & CTA data
  const {
    data: vtaCtaData,
    isLoading: isVtaCtaLoading,
  } = useVtaCtaPublisherSummary(selectedType, basePayload, !!basePayload);

  // Transform VTA & CTA data directly
  const vtaCtaDataFromApi = useMemo(() => {
    if (vtaCtaData?.data && Array.isArray(vtaCtaData.data)) {
      return vtaCtaData.data.map((item: any) => ({
        publisher_name: item?.["Publisher Name"],
        total_installs: item?.["Total Count"],
        vta: item?.["Vta"],
        percent_vta: item?.["Vta %"],
        cta: item?.["Cta"],
        percent_cta: item?.["Cta %"],
        }));
    }
    return [];
  }, [vtaCtaData]);

  // Payload for publisher-specific APIs
  const publisherPayload = useMemo(() => {
    if (!basePayload || !selectedPublisher) return undefined;
    return {
      ...basePayload,
      publisher: [selectedPublisher],
    };
  }, [basePayload, selectedPublisher]);

  // API call for State-wise Publisher Data
  const {
    data: stateWiseData,
    isLoading: isStateWiseLoading,
  } = useStateWisePublisher(selectedType, publisherPayload, !!publisherPayload);

  // Transform State-wise data directly
  const stateWiseDataFromApi = useMemo(() => {
    if (stateWiseData?.data && Array.isArray(stateWiseData.data)) {
      return stateWiseData.data.map((item: any) => ({
          label: item.label,
          visit: item.visit,
          percentage: item.percentage,
        fill: item.fill || "#1976d2",
      }));
    }
    return [];
  }, [stateWiseData]);

  // API call for Make Model Data
  const {
    data: makeModelData,
    isLoading: isMakeModelLoading,
  } = useMakeModelWisePublisher(selectedType, publisherPayload, !!publisherPayload);

  // Transform Make Model data directly
  const makeModelDataFromApi = useMemo(() => {
    if (makeModelData?.data && Array.isArray(makeModelData.data)) {
      return makeModelData.data.map((item: any) => ({
          label: item.label,
        visit: item.visit,
        price: parseFloat(item.price.replace(/[₹$€£¥,]/g, "")) || 0,
        fill: item.fill || "#1976d2",
      }));
    }
    return [];
  }, [makeModelData]);

  // API call for OS Version Data
  const {
    data: osVersionData,
    isLoading: isOsVersionLoading,
  } = usePublisherWiseOsDetails(selectedType, publisherPayload, !!publisherPayload);

  // Transform OS Version data directly
  const osVersionDataFromApi = useMemo(() => {
    if (osVersionData?.data && Array.isArray(osVersionData.data)) {
      return osVersionData.data.map((item: any) => ({
          label: item.label,
        publishers: item.visit,
        fill: item.fill || "#1976d2",
      }));
    }
    return [];
  }, [osVersionData]);

  // CVR payload
  const cvrPayload = useMemo(() => {
    if (
      !basePayload ||
      !existingPublisherdata?.Affiliate ||
      existingPublisherdata.Affiliate.length === 0 ||
      !existingEventTypeData ||
      existingEventTypeData.length === 0
    ) {
      return undefined;
    }

    const allPublishers = Object.values(existingPublisherdata || {}).flat();
    const publisherFilter =
      cvrPublisherFilter.length === 0 ||
      cvrPublisherFilter.includes("all") ||
      cvrPublisherFilter.length === allPublishers.length
        ? ["all"]
        : cvrPublisherFilter;

    const eventTypeFilter =
      cvrEventTypeFilter.length === 0 ||
      cvrEventTypeFilter.length === existingEventTypeData.length
        ? ["all"]
        : cvrEventTypeFilter;

    return {
      ...basePayload,
      publisher: publisherFilter,
      event_type: eventTypeFilter,
      search_term: debouncedSearchTerm,
      page_number: currentPage,
      record_limit: limit,
    };
  }, [
    basePayload,
    existingPublisherdata,
    existingEventTypeData,
    cvrPublisherFilter,
    cvrEventTypeFilter,
    debouncedSearchTerm,
    currentPage,
    limit,
  ]);

  // API call for CVR data - Always use "event" type for CVR
  const { data: cvrApiData, isLoading: isCvrApiLoading } = useCvr(
    "event",
    cvrPayload,
    !!cvrPayload
  );

  // Extract CVR data and transform directly
  const cvrDataFromApi = useMemo(() => {
    if (cvrApiData) {
      if (cvrApiData?.data && Array.isArray(cvrApiData.data)) {
        return cvrApiData.data;
      } else if (Array.isArray(cvrApiData)) {
        return cvrApiData;
      }
    }
    return [];
  }, [cvrApiData]);

  // Extract CVR pagination info
  useEffect(() => {
    if (cvrApiData) {
      if (cvrApiData?.Total_pages) {
        setCvrTotalPages(cvrApiData.Total_pages);
      }
      if (cvrApiData?.Total_records) {
        setCvrTotalRecords(cvrApiData.Total_records);
      }
    }
  }, [cvrApiData]);

  // Generate CVR columns dynamically
  const cvrColumns = useMemo(() => {
    if (cvrDataFromApi.length === 0) return [];
    const firstRow = cvrDataFromApi?.[0];
    if (!firstRow) return [];
    return Object.keys(firstRow).map((key) => {
      if (
        key === "action" ||
        key === "buttons" ||
        key.toLowerCase().includes("button")
    ) {
        return {
          title: key
            .replace(/_/g, " ")
            .replace(/\b\w/g, (l) => l.toUpperCase()),
          key: key,
          render: (item: any) => (
            <div className="flex gap-2">
              <button className="px-3 py-1 bg-primary text-white rounded hover:bg-primary/90 text-sm">
                View Details
              </button>
            </div>
          ),
        };
    }

      return {
        title: key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
        key: key,
        render: (item: any) => {
          const value = item?.[key];
          if (typeof value === "object" && value !== null) {
            if (Array.isArray(value)) {
              return value.join(", ");
            }
            return JSON.stringify(value);
          }
          if (typeof value === "number") {
            return value.toLocaleString();
          } else if (typeof value === "string" && value.includes("%")) {
            return value;
          } else if (
            typeof value === "string" &&
            !isNaN(Number(value.replace(/,/g, "")))
    ) {
            return Number(value.replace(/,/g, "")).toLocaleString();
          }
          return String(value || "");
        },
      };
    });
  }, [cvrDataFromApi]);

  // Incent Samples payload
  const incentSamplesPayload = useMemo(() => {
    if (
      !basePayload ||
      !debouncedIncentSamplesPublisherFilter ||
      debouncedIncentSamplesPublisherFilter.length === 0
    ) {
      return undefined;
    }
    return {
      ...basePayload,
      publisher: debouncedIncentSamplesPublisherFilter,
    };
  }, [basePayload, debouncedIncentSamplesPublisherFilter]);

  // API call for Incent Samples Data
  const {
    data: incentSamplesApiData,
    isLoading: isIncentSamplesLoading,
  } = useIncentSamples(selectedType, incentSamplesPayload, !!incentSamplesPayload);

  // Transform Incent Samples data directly
  const incentSamplesData = useMemo(() => {
    if (
      incentSamplesApiData?.data &&
      Array.isArray(incentSamplesApiData.data)
    ) {
      return incentSamplesApiData.data.map((item: any) => ({
        date: item?.Date,
        publisher_name: item?.["Publisher Name"],
        sub_publisher_name: item?.["Sub Publisher Name"],
        campaign_id: item?.["Campaign Id"],
        agency_id: item?.["Agency Id"],
        incent_wall: item?.["Incent Wall"],
        screenshot_url: item?.["Screenshot Url"],
        tracking_url: item?.["Tracking Url"],
        country: item?.Country,
      }));
    }
    return [];
  }, [incentSamplesApiData]);

  // CVR loading states
  const isCvrLoading = isCvrApiLoading && !isSearching;
  const isCvrSearchLoading = isCvrApiLoading && isSearching;

  // Add loading state management
  const isInitialLoading = useMemo(() => {
    return (
      isPackageLoading ||
      isCleanInstallLoading ||
      isFraudulentInstallLoading ||
      isCleanEventLoading ||
      isFraudulentEventLoading ||
      isVtaCtaLoading ||
      isStateWiseLoading ||
      isMakeModelLoading ||
      isOsVersionLoading ||
      eventTypeFilterApi?.isLoading
    );
  }, [
      isPackageLoading,
    isCleanInstallLoading,
    isFraudulentInstallLoading,
    isCleanEventLoading,
    isFraudulentEventLoading,
    isVtaCtaLoading,
    isStateWiseLoading,
    isMakeModelLoading,
    isOsVersionLoading,
    eventTypeFilterApi?.isLoading,
  ]);

  const finalOsVersionData =
    osVersionDataFromApi.length > 0
      ? osVersionDataFromApi
      : [
    { label: "iOS 14", publishers: 5 },
    { label: "iOS 13", publishers: 4 },
    { label: "iOS 12", publishers: 3 },
    { label: "iOS 11", publishers: 5 },
  ];


  const [selectedFrequency, setSelectedFrequency] = useState("Daily");
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  const handleExpand = (key: string) => {
    onExpand(key, cardRefs, expandedCard, setExpandedCard);
  };

  const onExportChart = async (
    format: string,
    title: string,
    chartId: string
  ) => {
    if (format === "png") {
      const ref = cardRefs.current[chartId];
      if (!ref) return;
      
      try {
        const screenshot = await domToImage.toPng(ref);
        downloadURI(screenshot, `${title}.png`);
      } catch (error) {
        // Error exporting chart
      }
    }
  };

  // Debounce search term
  useEffect(() => {
    if (searchTerm !== debouncedSearchTerm) {
      setIsSearching(true);
    }
    
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
      setIsSearching(false);
    }, 500); // 500ms delay

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, debouncedSearchTerm]);


  // Debounce incent samples publisher filter
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedIncentSamplesPublisherFilter(incentSamplesPublisherFilter);
    }, 500); // 500ms delay

    return () => {
      clearTimeout(timer);
    };
  }, [incentSamplesPublisherFilter]);


  // Use API data if available, otherwise fall back to static data for Make Model
  const finalMakeModelData =
    makeModelDataFromApi.length > 0 ? makeModelDataFromApi : [];

  // Export payload for CVR
  const cvrExportPayload = useMemo(() => {
    if (
      !basePayload ||
      !existingPublisherdata?.Affiliate ||
      existingPublisherdata.Affiliate.length === 0 ||
      !existingEventTypeData ||
      existingEventTypeData.length === 0
    ) {
      return undefined;
    }

    const allPublishers = Object.values(existingPublisherdata || {}).flat();
    const publisherFilter =
      cvrPublisherFilter.length === 0 ||
        cvrPublisherFilter.includes("all") || 
      cvrPublisherFilter.length === allPublishers.length
        ? ["all"]
        : cvrPublisherFilter;
      
    const eventTypeFilter =
      cvrEventTypeFilter.length === 0 ||
      cvrEventTypeFilter.length === existingEventTypeData.length
        ? ["all"]
        : cvrEventTypeFilter;
      
    return {
      ...basePayload,
        publisher: publisherFilter,
        event_type: eventTypeFilter,
        search_term: debouncedSearchTerm,
        page_number: currentPage,
        record_limit: limit,
        export_type: "csv",
    };
  }, [
    basePayload,
    existingPublisherdata,
    existingEventTypeData,
    cvrPublisherFilter,
    cvrEventTypeFilter,
    debouncedSearchTerm,
    currentPage,
    limit,
  ]);

  // Export API call for CVR - Always use "event" type for CVR
  const cvrExportApi = useCvr(
    "event",
    cvrExportPayload,
    false // Don't auto-fetch, we'll trigger it manually
  );

  // Effect to handle CVR export response
  useEffect(() => {
    if (cvrExportApi.data?.url) {
      const link = document.createElement("a");
      link.href = cvrExportApi.data.url;
      link.setAttribute("download", "CVR.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }, [cvrExportApi.data]);

  const handleExports = async () => {
    if (cvrExportPayload) {
      cvrExportApi.refetch();
    }
  };

  const IncentSampleCard: React.FC<{ data: Record<string, any> }> = ({
    data,
  }) => {
    const { screenshot_url, ...otherData } = data;
    return (
      <Card className="w-full h-[290px] overflow-hidden border">
        <CardContent className="p-4 ">
          <div className="flex h-full w-full justify-between">
            {/* Left side - Dynamic Details */}
            <div className="w-2/3 space-y-4">
              {Object.entries(otherData).map(([key, value]) => {
                // Helper function to detect and render URLs
                const renderValue = (val: string) => {
                  // Check if the value is a URL
                  const urlRegex = /^(https?:\/\/[^\s]+)/i;
                  const isUrl = urlRegex.test(val);
                  
                  if (isUrl) {
                    return (
                      <a
                        href={val}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-blue-600 hover:text-blue-800 underline cursor-pointer"
                        title={val}
                      >
                        {val.length > 20 ? val.slice(0, 20) + "..." : val}
                      </a>
                    );
                  }
                  
                  return (
                    <span className="text-xs" title={val}>
                      {val.length > 20 ? val.slice(0, 20) + "..." : val}
                    </span>
                  );
                };
                
                return (
                  <div key={key} className="flex items-center gap-2 text-sm">
                    <span className="w-2 h-2 bg-black rounded-full"></span>
                    <span className="text-sm font-semibold">
                      {key
                        .split("_")
                        .map(
                          (word) => word.charAt(0).toUpperCase() + word.slice(1)
                        )
                        .join(" ")}
                      :
                    </span>
                    {renderValue(String(value))}
                  </div>
                );
              })}
            </div>
            {/* Right side - screenshot_url or Image if present */}
            <div className="w-1/2 flex items-center justify-center pl-16">
              {screenshot_url ? (
                // Display the actual image from the URL
                <div className="w-48 h-64">
                  <img
                    src={screenshot_url}
                    alt="Screenshot"
                    className="w-full h-full object-cover rounded-lg shadow-lg border"
                    onError={(e) => {
                      // Fallback if image fails to load
                      const target = e.target as HTMLImageElement;
                      target.style.display = "none";
                      target.parentElement!.innerHTML =
                        '<div class="w-full h-full flex items-center justify-center bg-gray-100 rounded-lg text-gray-400 text-sm">Image not available</div>';
                    }}
                  />
                </div>
              ) : (
                <div className="w-48 h-64 flex items-center justify-center bg-gray-100 rounded-lg text-gray-400">
                  No screenshot_url
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <>
      <div className="flex flex-col gap-2 w-full">
        {/* Install & Event Analytics Section with Carousel */}
        <div className="w-full backdrop-blur-lg bg-background/80 dark:bg-card/80 border border-border/40 rounded-xl shadow-lg p-2 transition-all duration-300">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-8 w-1 bg-gradient-to-b from-primary to-secondary rounded-full" />
            <h2 className="text-body sm:text-subHeader font-bold text-foreground gradient-text">
            Install & Event Analytics
            </h2>
            <div className="h-8 w-1 bg-gradient-to-b from-secondary to-primary rounded-full" />
          </div>

          <div className="relative">
            <Carousel
              opts={{
                align: "start",
                loop: true,
                slidesToScroll: 1,
              }}
              className="w-full"
            >
              <div className="flex items-center gap-2">
                <CarouselPrevious className="static translate-y-0 hover:bg-primary/10 transition-colors" />
                <div className="flex-1 overflow-hidden">
                  <CarouselContent className="-ml-2">
                    {/* Valid Install Chart */}
                    <CarouselItem className="pl-2 md:pl-4 basis-full md:basis-1/2">
            <Card
              ref={(el) => {
                          if (el) cardRefs.current["valid_install"] = el;
              }}
                        className="h-full border-2 border-green-200 dark:border-green-800 hover:border-green-400 dark:hover:border-green-600 transition-all duration-300 shadow-md hover:shadow-lg"
            >
                        <CardContent className="p-2 h-full">
                  <ProgressBarChart
                            chartData={cleanInstallData?.data || []}
                    title="Valid Install - Top 10 Publishers"
                            isLoading={isCleanInstallLoading}
                            handleExpand={() => handleExpand("valid_install")}
                            handleExportPng={(title, key) =>
                      onExportChart(
                        "png",
                                "Valid Install - Top 10 Publishers",
                                "valid_install"
                      )
                    }
                            exportKey="valid_install"
                  />
                        </CardContent>
                      </Card>
                    </CarouselItem>

                    {/* Invalid Install Chart */}
                    <CarouselItem className="pl-2  basis-full md:basis-1/2">
                      <Card
                        ref={(el) => {
                          if (el) cardRefs.current["invalid_install"] = el;
                        }}
                        className="h-full border-2 border-red-200 dark:border-red-800 hover:border-red-400 dark:hover:border-red-600 transition-all duration-300 shadow-md hover:shadow-lg"
                      >
                        <CardContent className="p-2 h-full">
                  <ProgressBarChart
                            chartData={fraudulentInstallData?.data || []}
                    title="Invalid Install - Top 10 Publishers"
                            isLoading={isFraudulentInstallLoading}
                            handleExpand={() => handleExpand("invalid_install")}
                            handleExportPng={(title, key) =>
                      onExportChart(
                        "png",
                                "Invalid Install - Top 10 Publishers",
                                "invalid_install"
                      )
                    }
                            exportKey="invalid_install"
                  />
                        </CardContent>
            </Card>
                    </CarouselItem>

                    {/* Valid Event Chart */}
                    <CarouselItem className="pl-2  basis-full md:basis-1/2">
            <Card
              ref={(el) => {
                          if (el) cardRefs.current["valid_event"] = el;
              }}
                        className="h-full border-2 border-blue-200 dark:border-blue-800 hover:border-blue-400 dark:hover:border-blue-600 transition-all duration-300 shadow-md hover:shadow-lg"
            >
                        <CardContent className="p-2 h-full">
                  <ProgressBarChart
                            chartData={cleanEventData?.data || []}
                    title="Valid Event - Top 10 Publishers"
                            isLoading={isCleanEventLoading}
                            handleExpand={() => handleExpand("valid_event")}
                            handleExportPng={(title, key) =>
                      onExportChart(
                        "png",
                                "Valid Event - Top 10 Publishers",
                                "valid_event"
                      )
                    }
                            exportKey="valid_event"
                  />
                        </CardContent>
                      </Card>
                    </CarouselItem>

                    {/* Invalid Event Chart */}
                    <CarouselItem className="pl-2 basis-full md:basis-1/2">
                      <Card
                        ref={(el) => {
                          if (el) cardRefs.current["invalid_event"] = el;
                        }}
                        className="h-full border-2 border-orange-200 dark:border-orange-800 hover:border-orange-400 dark:hover:border-orange-600 transition-all duration-300 shadow-md hover:shadow-lg"
                      >
                        <CardContent className="p-2 h-full">
                  <ProgressBarChart
                            chartData={fraudulentEventData?.data || []}
                    title="Invalid Event - Top 10 Publishers"
                            isLoading={isFraudulentEventLoading}
                            handleExpand={() => handleExpand("invalid_event")}
                            handleExportPng={(title, key) =>
                      onExportChart(
                        "png",
                                "Invalid Event - Top 10 Publishers",
                                "invalid_event"
                      )
                    }
                            exportKey="invalid_event"
                  />
                        </CardContent>
                      </Card>
                    </CarouselItem>
                  </CarouselContent>
                </div>
                <CarouselNext className="static translate-y-0 hover:bg-primary/10 transition-colors" />
              </div>
            </Carousel>
          </div>
        </div>

        {/* VTA & CTA Ratios Section */}
        <div className="w-full backdrop-blur-lg bg-background/80 dark:bg-card/80 border border-border/40 rounded-xl shadow-lg p-4 transition-all duration-300">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="h-8 w-1 bg-gradient-to-b from-primary to-secondary rounded-full" />
            <h2 className="text-body sm:text-subHeader font-bold text-foreground gradient-text">
            VTA & CTA Ratios
            </h2>
            <div className="h-8 w-1 bg-gradient-to-b from-secondary to-primary rounded-full" />
          </div>
          <ResizableTable
            columns={vtaCtaColumns}
            data={vtaCtaDataFromApi}
            isTableDownload={false}
            isSearchable={true}
            SearchTerm={vtaCtaSearchTerm}
            setSearchTerm={setVtaCtaSearchTerm}
            isUserTable={false}
            isLoading={isVtaCtaLoading || isInitialLoading}
          />
        </div>

        {/* Charts Section - Three Cards in One Row */}
        <div className="w-full backdrop-blur-lg bg-background/80 dark:bg-card/80 border border-border/40 rounded-xl shadow-lg p-4 transition-all duration-300">
          <div className="flex items-center justify-between gap-4 mb-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-1 bg-gradient-to-b from-primary to-secondary rounded-full" />
              <h2 className="text-body sm:text-subHeader font-bold text-foreground gradient-text">
                Publisher Wise
              </h2>
              <div className="h-8 w-1 bg-gradient-to-b from-secondary to-primary rounded-full" />
            </div>
            <div className="w-48">
              <MFSingleSelect
                items={publisherItems}
                placeholder={
                  publishersFilterApi?.isLoading
                    ? "Loading publishers..."
                    : "Select Publisher"
                }
                title="Affiliate Publishers"
                className="w-full"
                value={selectedPublisher}
                onValueChange={handlePublisherChange}
              />
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-2 w-full">
            {/* OS Version Distribution */}
            <div className="w-full">
                                  <StackedBarChart
                ref={(el) => {
                  if (el) cardRefs.current["os_version_distribution"] = el;
                }}
                    chartData={finalOsVersionData}
                chartConfig={{ publishers: { label: "Install", color: "#1976d2" } }}
                title="OS Version Distribution"
                titleIcon={<BarChart3 className="w-4 h-4 text-primary" />}
                onExport={() => {
                    onExportChart(
                      "png",
                      "OS Version Distribution",
                      "os_version_distribution"
                  );
                }}
                exportKey="os_version_distribution"
                onExpand={() => handleExpand("os_version_distribution")}
            isLoading={
              isOsVersionLoading ||
              (isInitialLoading && !isSearching) ||
              !selectedPublisher
            }
                isHorizontal={true}
                isInformCard={false}
                isLegend={false}
                  isCartesian={true}
                  yAxis={{ dataKey: "label" }}
                  AxisLabel="Count"
                barHeight="13rem"
                cardHeight="16.5rem"
                chartMargins={{ top: 0, right: -10, left: -10, bottom: 0 }}
              />
            </div>

            {/* State-wise Install Counts */}
            <div className="w-full">
              <StackedBarChart
                ref={(el) => {
                  if (el) cardRefs.current["state_wise_distribution"] = el;
                }}
                chartData={
                  stateWiseDataFromApi.length > 0 ? stateWiseDataFromApi : []
                }
                chartConfig={{ visit: { label: "Install", color: "#1976d2" } }}
                title="Top State-wise Install Counts"
                titleIcon={<TrendingUp className="w-4 h-4 text-primary" />}
                onExport={() => {
                    onExportChart(
                      "png",
                      "State-wise Install Counts",
                      "state_wise_distribution"
                  );
                }}
                exportKey="state_wise_distribution"
                onExpand={() => handleExpand("state_wise_distribution")}
                isLoading={
                  isStateWiseLoading ||
                  publishersFilterApi?.isLoading ||
                  (isInitialLoading && !isSearching) ||
                  !selectedPublisher
                }
                isHorizontal={true}
                isInformCard={false}
                isLegend={false}
                  isCartesian={true}
                  yAxis={{ dataKey: "label" }}
                  AxisLabel="Count"
                barHeight="13rem"
                cardHeight="16.5rem"
                chartMargins={{ top: 0, right: -10, left: -10, bottom: 0 }}
                />
              </div>
            </div>
          <div
            ref={(el) => {
                if (el) cardRefs.current["event_traffic_trend"] = el;
            }}
            className="w-full mt-2"
          >
            <StackedBarWithLine1
              chartData={finalMakeModelData}
              chartConfig={{ visit: { label: "Install", color: "#1976d2" } }}
                  title="Top Make Model Wise Install Counts"
              titleIcon={<TrendingUp className="w-4 h-4 text-primary" />}
              frequencyOptions={["Daily", "Weekly", "Monthly"]}
                  selectedFrequency={selectedFrequency}
              handleFrequencyChange={(value: string) => {
                setSelectedFrequency(value);
              }}
              frequencyPlaceholder="Daily"
              handleExportCsv={() => {}}
              handleExpand={() => handleExpand("event_traffic_trend")}
              handleExportPng={() => {
                      onExportChart(
                        "png",
                        "Top Make Model Wise Install Counts",
                        "event_traffic_trend"
                );
              }}
                  exportKey="event_traffic_trend"
                    isLegend={false}
              isLoading={
                isMakeModelLoading || (isInitialLoading && !isSearching)
              }
              barHeight="11rem"
              contentHeight="13rem"
              cardHeight="16.5rem"
              chartMargins={{ top: 0, right: -10, left: -10, bottom: -4 }}
                  />
                </div>
        </div>

        {/* CVR Table Section */}
        <div className="w-full backdrop-blur-lg bg-background/80 dark:bg-card/80 border border-border/40 rounded-xl shadow-lg p-4 transition-all duration-300">
          <div className="flex items-center justify-between gap-4 mb-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-1 bg-gradient-to-b from-primary to-secondary rounded-full" />
              <h2 className="text-body sm:text-subHeader font-bold text-foreground gradient-text">
                CVR
              </h2>
              <div className="h-8 w-1 bg-gradient-to-b from-secondary to-primary rounded-full" />
            </div>
            <div className="flex items-center gap-4">
              <Filter
                filter={cvrFilter.publishersFilter}
                onChange={handleCvrFilterChange}
                grouped={true}
                publisherGroups={existingPublisherdata}
              />
              <div className="w-32 sm:w-48">
                <MultipleSelect
                  options={existingEventTypeData}
                  selectedValues={cvrEventTypeFilter}
                  onSelectionChange={handleEventTypeChange}
                  placeholder={
                    eventTypeFilterApi?.isLoading
                      ? "Loading event types..."
                      : "Select Event Types"
                  }
                  disabled={eventTypeFilterApi?.isLoading}
                />
              </div>
            </div>
          </div>
          <ResizableTable
            columns={cvrColumns}
            data={cvrDataFromApi.length > 0 ? cvrDataFromApi : []}
            isTableDownload={false}
            isSearchable={true}
            SearchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            isUserTable={false}
            isLoading={
              isCvrLoading ||
              isCvrSearchLoading ||
              isSearching ||
              isInitialLoading
            }
            emptyStateMessage="No CVR data found"
            isPaginated={true}
            totalPages={cvrTotalPages}
            totalRecords={cvrTotalRecords}
            pageNo={currentPage}
            limit={limit}
            onPageChangeP={(newPage: number) => {
              setCurrentPage(newPage);
            }}
            onLimitChange={(newLimit: number) => {
              setLimit(newLimit);
              setCurrentPage(1);
            }}
            actionButton={
              <>
                <Button variant="outline" size="sm" onClick={handleExports}>
                  {cvrExportApi.isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Export
                    </>
                  ) : (
                    <>
                      <MdFileDownload className="mr-2 h-4 w-4" />
                      Export
                    </>
                  )}
                </Button>
              </>
            }
          />
        </div>

        <div className="w-full backdrop-blur-lg bg-background/80 dark:bg-card/80 border border-border/40 rounded-xl shadow-lg p-4 transition-all duration-300">
          <div className="flex items-center justify-between gap-4 mb-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-1 bg-gradient-to-b from-primary to-secondary rounded-full" />
              <h2 className="text-body sm:text-subHeader font-bold text-foreground gradient-text">
                Incent Samples
              </h2>
              <div className="h-8 w-1 bg-gradient-to-b from-secondary to-primary rounded-full" />
            </div>
            <div className="flex items-center gap-4">
              <Filter
                filter={incentSamplesFilter.publishersFilter}
                onChange={(filterState: any) => {
                  if (filterState?.Publishers) {
                    const publisherPayload = {
                      publishers: filterState.Publishers.isSelectAll
                        ? ["all"]
                        : [
                            ...(filterState.Publishers.filters?.Affiliate ||
                              []),
                            ...(filterState.Publishers.filters?.[
                              "Whitelisted Publisher"
                            ] || []),
                          ],
                    };
                    setIncentSamplesPublisherFilter(
                      publisherPayload.publishers
                    );
                  }
                }}
                grouped={true}
                publisherGroups={existingPublisherdata}
              />
            </div>
          </div>
          <div className="w-full max-w-full overflow-hidden">
            {isIncentSamplesLoading || isInitialLoading ? (
                <div className="flex items-center justify-center h-[300px] sm:h-[300px] lg:h-[400px]">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : incentSamplesData.length > 0 ? (
              <div className="relative">
                <Carousel
                  opts={{ align: "start", loop: true }}
                  className="w-full"
                >
                  <div className="flex items-center gap-4">
                    <CarouselPrevious className="static" />
                    <div className="flex-1 overflow-hidden">
                      <CarouselContent>
                        {incentSamplesData?.map(
                          (sample: any, index: number) => (
                          <CarouselItem
                            key={index}
                            className="basis-full md:basis-1/2"
                          >
                            <div className="w-full h-full p-2">
                              <IncentSampleCard data={sample} />
                            </div>
                          </CarouselItem>
                          )
                        )}
                      </CarouselContent>
                    </div>
                    <CarouselNext className="static" />
                  </div>
                </Carousel>
              </div>
            ) : (
              <div className="w-full h-64 flex items-center justify-center ">
               <span className="text-small-font">No Data Found!</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Analytics;
